#include <string.h>
#include "aes_test.h"

#include "../iscrypt.h"
#include "../iscrypt_aes.h"


unsigned char AES_KEY[] = 
{
	0X00,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C,0X0D,0X0E,0X0F,	\
	0X10,0X11,0X12,0X13,0X14,0X15,0X16,0X17,0X18,0X19,0X1A,0X1B,0X1C,0X1D,0X1E,0X1F
};

unsigned char AES_IV[] = 
{
	0X01,0X23,0X45,0X67,0X89,0XAB,0XCD,0XEF,0XFE,0XDC,0XBA,0X98,0X76,0X54,0X32,0X10
};

unsigned char AES_PLAINTEXT[] = 
{
	0X00,0X11,0X22,0X33,0X44,0X55,0X66,0X77,0X88,0X99,0XAA,0XBB,0XCC,0XDD,0XEE,0XFF,	\
	0X00,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C,0X0D,0X0E,0X0F,	\
	0X10,0X11,0X12,0X13,0X14,0X15,0X16,0X17,0X18,0X19,0X1A,0X1B,0X1C,0X1D,0X1E,0X1F,	\
	0X20,0X21,0X22,0X23,0X24,0X25,0X26,0X27,0X28,0X29,0X2A,0X2B,0X2C,0X2D,0X2E,0X2F
};

unsigned char AES128_CIPHERTEXT_ECB[] = 
{
	0X69,0XC4,0XE0,0XD8,0X6A,0X7B,0X04,0X30,0XD8,0XCD,0XB7,0X80,0X70,0XB4,0XC5,0X5A,	\
	0X0A,0X94,0X0B,0XB5,0X41,0X6E,0XF0,0X45,0XF1,0XC3,0X94,0X58,0XC6,0X53,0XEA,0X5A,	\
	0X07,0XFE,0XEF,0X74,0XE1,0XD5,0X03,0X6E,0X90,0X0E,0XEE,0X11,0X8E,0X94,0X92,0X93,	\
	0X5B,0XE8,0X7E,0X2E,0X5B,0X44,0X7C,0X94,0X4B,0X21,0XC9,0XAF,0X77,0X56,0XC0,0XD8
};

unsigned char AES128_CIPHERTEXT_CBC[] = 
{
	0X2F,0X31,0X6E,0XC2,0X15,0X07,0XC0,0X76,0XC1,0X94,0XE9,0X60,0X79,0X26,0X11,0X88,	\
	0X8F,0X82,0XB9,0X91,0X04,0XF2,0X68,0XBC,0X16,0X3D,0X82,0XF7,0X8A,0X1D,0XAD,0X4F,	\
	0XFE,0X6A,0XD5,0X9E,0XC5,0X90,0X98,0X86,0X81,0X9F,0X7E,0X64,0X8B,0X34,0X55,0X0A,	\
	0XE2,0XC5,0XE4,0X2B,0X42,0X7F,0X81,0XB5,0X87,0X46,0XF2,0X83,0XA6,0X7F,0XD5,0XF1
};



////////////////////////////////////////////////////////////////
unsigned long AES128_TEST( void )
{
	BLOCKCIPHERPARAM BlockCipherParam;
	unsigned char Output[64];

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_ECB | SYM_ENCRYPT | SYM_AES128;
	BlockCipherParam.pbKey = AES_KEY;
	BlockCipherParam.pbIV = NULL;

	BlockCipherParam.pbInput = AES_PLAINTEXT;
	BlockCipherParam.TotalBlock = 4;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != AESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(AES128_CIPHERTEXT_ECB, Output, 4*AES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_ECB | SYM_DECRYPT | SYM_AES128;
	BlockCipherParam.pbKey = AES_KEY;
	BlockCipherParam.pbIV = NULL;

	BlockCipherParam.pbInput = Output;
	BlockCipherParam.TotalBlock = 4;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != AESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(AES_PLAINTEXT, Output, 4*AES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_CBC | SYM_ENCRYPT | SYM_AES128;
	BlockCipherParam.pbKey = AES_KEY;
	BlockCipherParam.pbIV = AES_IV;

	BlockCipherParam.pbInput = AES_PLAINTEXT;
	BlockCipherParam.TotalBlock = 4;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != AESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(AES128_CIPHERTEXT_CBC, Output, 4*AES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_CBC | SYM_DECRYPT | SYM_AES128;
	BlockCipherParam.pbKey = AES_KEY;
	BlockCipherParam.pbIV = AES_IV;

	BlockCipherParam.pbInput = Output;
	BlockCipherParam.TotalBlock = 4;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != AESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(AES_PLAINTEXT, Output, 4*AES_BLOCK_SIZE))
	{
		return FAIL;
	}

	return SUCCESS;
}


