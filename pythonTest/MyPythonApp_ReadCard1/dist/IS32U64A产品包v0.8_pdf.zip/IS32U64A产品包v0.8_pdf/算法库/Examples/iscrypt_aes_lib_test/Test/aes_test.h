#ifndef __AES_TEST_H__
#define __AES_TEST_H__

unsigned long AES128_TEST( void );

#endif
