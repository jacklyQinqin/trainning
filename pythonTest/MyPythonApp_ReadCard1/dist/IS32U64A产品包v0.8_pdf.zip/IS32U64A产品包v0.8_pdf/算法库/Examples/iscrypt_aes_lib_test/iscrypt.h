/****************************************************************\
* Copyright (C) 2005-2012 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.11.28
* Description:
* 	
* Others:		
* 
* Function List:	
*   1. ......
*
* History:		
*   1. Date:	
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef	__IS_CRYPT_H__
#define __IS_CRYPT_H__


/* NULL Definition */
#ifndef NULL
#define NULL			0L
#endif /* NULL */


#ifndef MAX
#define MAX(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#ifndef TRUE
#define TRUE		1
#endif

#ifndef FALSE
#define FALSE		0
#endif

#define IS_EVEN(x)					(((x) & 1) ^ 1)
#define IS_ODD(x)					((x) & 1)
#define SWAP(x, y)					((x)^=(y), (y)^=(x), (x)^=(y))
#define	GET_BIT(iword, ibit)		(((iword) >> (ibit)) & 1)

#define BIT_TST(iword, ibit)		(((iword) >> (ibit)) & 1)
#define BIT_SET(iword, ibit)		((iword) |= (1<<(ibit)))
#define BIT_CLR(iword, ibit)		((iword) &= ~(1<<(ibit)))

#define ARRAY_BIT_TST(array, ibit)	BIT_TST((array)[(ibit)>>5], (ibit)&0x0000001F)
#define ARRAY_BIT_SET(array, ibit)	BIT_SET((array)[(ibit)>>5], (ibit)&0x0000001F)
#define ARRAY_BIT_CLR(array, ibit)	BIT_CLR((array)[(ibit)>>5], (ibit)&0x0000001F)


#define STORE32(x, y)	{	\
	(y)[0] = (unsigned char)((((unsigned long)x) >> 24) & 0x000000FF);	\
	(y)[1] = (unsigned char)((((unsigned long)x) >> 16) & 0x000000FF);	\
	(y)[2] = (unsigned char)((((unsigned long)x) >> 8 ) & 0x000000FF);	\
	(y)[3] = (unsigned char)((((unsigned long)x) >> 0 ) & 0x000000FF);	\
}

#define LOAD32(y, x)	{	\
	x = ((((unsigned long)(y)[0]) & 0x000000FF) << 24)	|	\
		((((unsigned long)(y)[1]) & 0x000000FF) << 16)	|	\
		((((unsigned long)(y)[2]) & 0x000000FF) << 8 )	|	\
		((((unsigned long)(y)[3]) & 0x000000FF) << 0 );		\
}

#define STORE64(x, y)	{	\
	(y)[0] = (unsigned char)(((x) >> 56) & 0x00000000000000FFUL);		\
	(y)[1] = (unsigned char)(((x) >> 48) & 0x00000000000000FFUL);		\
	(y)[2] = (unsigned char)(((x) >> 40) & 0x00000000000000FFUL);		\
	(y)[3] = (unsigned char)(((x) >> 32) & 0x00000000000000FFUL);		\
	(y)[4] = (unsigned char)(((x) >> 24) & 0x00000000000000FFUL);		\
	(y)[5] = (unsigned char)(((x) >> 16) & 0x00000000000000FFUL);		\
	(y)[6] = (unsigned char)(((x) >> 8 ) & 0x00000000000000FFUL);		\
	(y)[7] = (unsigned char)(((x) >> 0 ) & 0x00000000000000FFUL);		\
}

#define LOAD64(y, x)	{	\
	x = ((((unsigned long long)(y)[0]) & 0x00000000000000FFUL) << 56)	|	\
		((((unsigned long long)(y)[1]) & 0x00000000000000FFUL) << 48)	|	\
		((((unsigned long long)(y)[2]) & 0x00000000000000FFUL) << 40)	|	\
		((((unsigned long long)(y)[3]) & 0x00000000000000FFUL) << 32)	|	\
		((((unsigned long long)(y)[4]) & 0x00000000000000FFUL) << 24)	|	\
		((((unsigned long long)(y)[5]) & 0x00000000000000FFUL) << 16)	|	\
		((((unsigned long long)(y)[6]) & 0x00000000000000FFUL) << 8 )	|	\
		((((unsigned long long)(y)[7]) & 0x00000000000000FFUL) << 0 );		\
}


#define ROL32(x, y)		\
	((((unsigned long)x) << (((unsigned long)y) & 0x0000001FUL))	|	\
	(((unsigned long)x) >> (0x00000020UL - (((unsigned long)y) & 0x0000001FUL))))

#define ROR32(x, y)		\
	((((unsigned long)x) >> (((unsigned long)y) & 0x0000001FUL))	|	\
	(((unsigned long)x) << (0x00000020UL - (((unsigned long)y) & 0x0000001FUL))))

#define SHR32(x, y)		(((unsigned long)x) >> (((unsigned long)y) & 0x0000001FUL))



#define ROL64(x, y)		\
	((((unsigned long long)x) << (((unsigned long long)y) & 0x000000000000003FUL))	|	\
	(((unsigned long long)x) >> (0x0000000000000040UL - (((unsigned long long)y) & 0x000000000000003FUL))))

#define ROR64(x, y)		\
	((((unsigned long long)x) >> (((unsigned long long)y) & 0x000000000000003FUL))	|	\
	(((unsigned long long)x) << (0x0000000000000040UL - (((unsigned long long)y) & 0x000000000000003FUL))))

#define SHR64(x, y)		(((unsigned long long)x) >> (((unsigned long long)y) & 0x000000000000003FUL))



/* Algorithm Type */
#define DES				0x00
#define TDES			0x01
#define AES				0x02
#define SM1				0x10
#define SSF33			0x11
#define SMS4			0x12

#define SHA1			0x20
#define SHA224			0x21
#define SHA256			0x22
#define SHA384			0x23
#define SHA512			0x24
#define MD4				0x25
#define MD5				0x26
#define SM3				0x30

#define RSA				0x40
#define DSA				0x60

#define ECC				0x80
#define SM2				0x90

#define RC4				0xC0


/* RETURN VALUE */
#define SUCCESS						0x00
#define FAIL						0x01
#define UNKNOWN_ERROR				0x02
#define NOT_SUPPORT_YET_ERROR		0x03

#define NOT_INITIALIZE_ERROR		0x04
#define OBJECT_ERROR				0x05
#define MEMORY_ERROR				0x06

#define IN_DATA_LENGTH_ERROR		0x07
#define IN_DATA_ERROR				0x08

#define HASH_OBJECT_ERROR			0x09
#define HASH_ERROR					0x0A
#define HASH_NOT_EQUAL_ERROR		0x0B
#define OUT_OF_RANGE_ERROR			0x0C
#define PARAMETER_ERROR				0x0D

#define NO_ROOM_ERROR				0x30

extern void										*HdxaPointer;
#define InvalidPointer			((unsigned char *) 0xffffff)	/* used as an indicator for no pointer specified */
#endif

