/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		iscrypt_aes.c
* Author:			zh
* Version:			1.0.0.0
* Date:				2018.12.3
* Description:
*					Operations about AES
* Function List:
*					1.	AESCrypt
*					2.	 
* 
*
* History:
* 		<  author  >    <  date  >    <  version  >    <  description  >
*		
*		   
*
\****************************************************************/
#ifndef __IS_AES_H__
#define __IS_AES_H__

#include "iscrypt.h"
#include "iscrypt_symmetric.h"


unsigned char AESCrypt(BLOCKCIPHERPARAM *pBlockCipherParam);


#endif
