#ifdef __IS_COMPILE_ROM__

#include "CVL_SM3.h"
#include "CVL_SHA1.h"
#include "CVL_SHA256.h"
#include "CVL_SM2.h"
#include "CVL_SBC.h"
#include "global_func.h"


///////////////////////////////////////////////////////////

const void * const IS_FnTbl[] __attribute__((at(0x000B2000))) =
{
	(void *)CVL_SBCCrypt,
	
	(void *)CVL_SHA1Simple,
	(void *)CVL_SHA1Init,
	(void *)CVL_SHA1Update,
	(void *)CVL_SHA1Final,
		
	(void *)CVL_SHA256Simple,
	(void *)CVL_SHA256Init,
	(void *)CVL_SHA256Update,
	(void *)CVL_SHA256Final,
		
	(void *)CVL_SM3Simple,
	(void *)CVL_SM3Init,
	(void *)CVL_SM3Update,
	(void *)CVL_SM3Final,
 
	(void *)CVL_SM2KG,
	(void *)CVL_SM2Sign,
	(void *)CVL_SM2Verify,
	(void *)CVL_SM2Enc,
	(void *)CVL_SM2Dec,
		
	(void *)CVL_RSASignCRT,
	(void *)CVL_RSAVerify,
	
	(void *)CVL_SM9Pair,
	(void *)CVL_SM9MSKG,
	(void *)CVL_SM9USKG,
	(void *)CVL_SM9Sign,
	(void *)CVL_SM9Verify,
	(void *)CVL_SM9MEKG,
	(void *)CVL_SM9UEKG,
	(void *)CVL_SM9Enc,
	(void *)CVL_SM9Dec,
	
		
};

#else

const void * const IS_FnTbl[] =
{
	//SBC
	(void *)0x000b3fcd,
	//SHA1
	(void *)0x000b51c5,
	(void *)0x000b514d,
	(void *)0x000b5157,
	(void *)0x000b5197,
	//SHA256
	(void *)0x000b584f,
	(void *)0x000b5259,
	(void *)0x000b561b,
	(void *)0x000b5823,
	//SM3
	(void *)0x000b80d3,
	(void *)0x000b805b,
	(void *)0x000b8065,
	(void *)0x000b80a5,
	//SM2
	(void *)0x000b6463,
	(void *)0x000b6563,
	(void *)0x000b6c47,
	(void *)0x000b7077,
	(void *)0x000b7449,
	
	//RSA
	(void *)0x000b8e55,
	(void *)0x000b8ecf,
	
	//SM9
	(void *)0x000ba831,
	(void *)0x000ba759,
	(void *)0x000bab7d,	
	(void *)0x000bae67,
	(void *)0x000bb2ed,
	(void *)0x000bba4f,	
	(void *)0x000bbb03,
	(void *)0x000bbe7d,
	(void *)0x000bc4d9,			
	//SM1
	(void *)0x000c25db,
	//SM7
	(void *)0x000c1881,
	//SSF33
	(void *)0x000c1367,
	(void *)0x000c1911,			
};

#endif
