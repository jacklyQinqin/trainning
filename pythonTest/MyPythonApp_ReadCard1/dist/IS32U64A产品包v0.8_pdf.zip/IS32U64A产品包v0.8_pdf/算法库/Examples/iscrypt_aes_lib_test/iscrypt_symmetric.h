/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt_symmetric.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.11.28
* Description:
* 	
* Others:		
* 
* Function List:	
*   1. ......
*
* History:		
*   1. Date:	
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef __IS_SYMMETRIC_H__
#define __IS_SYMMETRIC_H__

#include "iscrypt.h"

/* */
typedef struct BlockCipherParam_st
{
	unsigned long OpMode;
    
    unsigned char *pbKey;

	unsigned char *pbIV;	

	unsigned char *pbInput;
    
    unsigned long TotalBlock;

	unsigned char *pbOutput;

	void *pReserve;

}BLOCKCIPHERPARAM;


/* CHOICE OF THE ALGORITHM TYPE */
#define SYM_ECB				0x00
#define SYM_CBC				0x01
#define SYM_CFB				0x02
#define SYM_OFB				0x03
#define SYM_MAC				0x04
#define SYM_CTR				0x05

#define SYM_ENCRYPT			0x00
#define SYM_DECRYPT			0x08

#define SYM_AES128			0x10
#define SYM_AES192			0x20
#define SYM_AES256			0x40


/* THE BLOCK SIZE OF EVERY BLOCK CIPHER ALGORITHM */
#define DES_BLOCK_SIZE		0x08
#define TDES_BLOCK_SIZE		0x08

#define SM1_BLOCK_SIZE		0x10
#define SSF33_BLOCK_SIZE	0x10
#define SM4_BLOCK_SIZE		0x10
#define SM7_BLOCK_SIZE      0x08

#define AES_BLOCK_SIZE		0x10


#endif
