#include "iscrypt.h"
#include "Test/aes_test.h"
void							*HdxaPointer 								__attribute__((at(0x000d0f80)));
int main( void )
{

 	unsigned long ret;
	
	ret = AES128_TEST();
	while (ret != SUCCESS);



	return 0;
}
