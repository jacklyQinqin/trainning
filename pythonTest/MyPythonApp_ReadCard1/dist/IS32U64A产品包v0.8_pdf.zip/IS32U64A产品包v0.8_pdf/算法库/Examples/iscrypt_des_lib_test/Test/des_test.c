#include <string.h>
#include "des_test.h"

#include "../iscrypt.h"
#include "../iscrypt_des.h"


unsigned char DES_KEY[] = 
{
	0X01,0X23,0X45,0X67,0X89,0XAB,0XCD,0XEF,
};

unsigned char TDES_KEY[] = 
{
	0X01,0X23,0X45,0X67,0X89,0XAB,0XCD,0XEF,	\
	0XFE,0XDC,0XBA,0X98,0X76,0X54,0X32,0X10,	\
	0X11,0X22,0X33,0X44,0X55,0X66,0X77,0X88
};

unsigned char DES_IV[] = 
{
	0X13,0X57,0X9B,0XDF,0X02,0X46,0X8A,0XCE
};

unsigned char DES_PLAINTEXT[] = 
{
	0X01,0X23,0X45,0X67,0X89,0XAB,0XCD,0XE7,	\
	0X89,0XAB,0XCD,0XE7,0X01,0X23,0X45,0X67,	\
	0X13,0X57,0X9B,0XDF,0X02,0X46,0X8A,0XCE,	\
	0X02,0X46,0X8A,0XCE,0X13,0X57,0X9B,0XDF,	\
	0X01,0X23,0X45,0X67,0X89,0XAB,0XCD,0XEF
};

unsigned char DES_CIPHERTEXT_ECB[] = 
{
	0XC9,0X57,0X44,0X25,0X6A,0X5E,0XD3,0X1D,	\
	0X65,0XFB,0X86,0XE1,0X1E,0X39,0XA2,0X63,	\
	0X07,0X1C,0XAD,0X79,0X67,0XF5,0X50,0XB4,	\
	0X96,0X35,0X8F,0X70,0X49,0X4C,0X02,0XB2,	\
	0X56,0XCC,0X09,0XE7,0XCF,0XDC,0X4C,0XEF
};

unsigned char DES_CIPHERTEXT_CBC[] = 
{
	0X7D,0X85,0X1C,0XFF,0XE1,0X84,0XFB,0X87,	\
	0X5C,0X71,0X96,0XC8,0X4F,0XDF,0X4E,0XCF,	\
	0X8B,0XDA,0XE0,0X42,0X4F,0XDC,0X41,0X8E,	\
	0X13,0X02,0XCE,0X0C,0X34,0X23,0XE3,0X31,	\
	0XE5,0XC7,0X3E,0X34,0XF1,0X98,0X26,0XDE
};

unsigned char TDES_2KEY_CIPHERTEXT_ECB[] = 
{
	0X7F,0X1D,0X0A,0X77,0X82,0X6B,0X8A,0XFF,	\
	0XAF,0X1A,0X75,0X49,0X3B,0X25,0XD7,0X44,	\
	0X0F,0X67,0XE2,0XEB,0X76,0XA5,0X25,0X9C,	\
	0XA0,0XD4,0X58,0XD7,0X67,0X96,0XFF,0X8E,	\
	0X1A,0X4D,0X67,0X2D,0XCA,0X6C,0XB3,0X35
};

unsigned char TDES_2KEY_CIPHERTEXT_CBC[] = 
{
	0X9E,0X78,0X5B,0XF2,0XF9,0XA7,0X57,0X04,	\
	0XC3,0X18,0X89,0X3E,0X40,0XDA,0XCE,0XBD,	\
	0X0E,0X4B,0X6D,0X8E,0X80,0X00,0XE8,0X74,	\
	0X4D,0XED,0X7F,0XCB,0XCF,0X38,0X58,0XA1,	\
	0X3B,0X23,0X47,0X62,0X7C,0X12,0X48,0XC1
};

unsigned char TDES_3KEY_CIPHERTEXT_ECB[] = 
{
    0X9D,0X6F,0X67,0X25,0XBA,0X79,0X25,0XA3,
    0X15,0XD2,0XED,0X8C,0XFC,0XC2,0XD0,0X2B,
    0X42,0XEB,0XF3,0X87,0XA6,0XD1,0X58,0XAC,
    0X6C,0X69,0X97,0X7B,0X83,0XE6,0X3F,0X8E,
    0XF6,0X53,0XF7,0X0A,0X75,0XFE,0X67,0X8A
};

unsigned char TDES_3KEY_CIPHERTEXT_CBC[] = 
{
    0XBD,0X71,0XA9,0X29,0XA5,0X2C,0XAE,0XD6,
    0X25,0X25,0XD0,0X8B,0X14,0XB0,0X40,0XE4,
    0XFB,0X4B,0XE3,0X3A,0X0E,0XFA,0X0B,0X01,
    0X65,0X26,0XCE,0X7A,0XA8,0XDA,0X7B,0X59,
    0X1E,0XAF,0X63,0XAA,0X19,0XAD,0X57,0X49
};
unsigned char Output[40];
////////////////////////////////////////////////////////////////
unsigned long DES_TEST( void )
{
	BLOCKCIPHERPARAM BlockCipherParam;


	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_ECB | SYM_ENCRYPT;
	BlockCipherParam.pbKey = DES_KEY;
	BlockCipherParam.pbIV = NULL;

	BlockCipherParam.pbInput = DES_PLAINTEXT;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != DESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(DES_CIPHERTEXT_ECB, Output, 5*DES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_ECB | SYM_DECRYPT;
	BlockCipherParam.pbKey = DES_KEY;
	BlockCipherParam.pbIV = NULL;

	BlockCipherParam.pbInput = DES_CIPHERTEXT_ECB;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != DESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(DES_PLAINTEXT, Output, 5*DES_BLOCK_SIZE))
	{
		return FAIL;
	}


	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_CBC | SYM_ENCRYPT;
	BlockCipherParam.pbKey = DES_KEY;
	BlockCipherParam.pbIV = DES_IV;

	BlockCipherParam.pbInput = DES_PLAINTEXT;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != DESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(DES_CIPHERTEXT_CBC, Output, 5*DES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_CBC | SYM_DECRYPT;
	BlockCipherParam.pbKey = DES_KEY;
	BlockCipherParam.pbIV = DES_IV;

	BlockCipherParam.pbInput = DES_CIPHERTEXT_CBC;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != DESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(DES_PLAINTEXT, Output, 5*DES_BLOCK_SIZE))
	{
		return FAIL;
	}

	return SUCCESS;
}

unsigned long TDES_TEST_2KEY( void )
{
	BLOCKCIPHERPARAM BlockCipherParam;
	//unsigned char Output[40];

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_ECB | SYM_ENCRYPT | SYM_EDE2;
	BlockCipherParam.pbKey = TDES_KEY;
	BlockCipherParam.pbIV = NULL;

	BlockCipherParam.pbInput = DES_PLAINTEXT;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != TDESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(TDES_2KEY_CIPHERTEXT_ECB, Output, 5*TDES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_ECB | SYM_DECRYPT | SYM_EDE2;
	BlockCipherParam.pbKey = TDES_KEY;
	BlockCipherParam.pbIV = NULL;

	BlockCipherParam.pbInput = TDES_2KEY_CIPHERTEXT_ECB;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != TDESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(DES_PLAINTEXT, Output, 5*TDES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_CBC | SYM_ENCRYPT | SYM_EDE2;
	BlockCipherParam.pbKey = TDES_KEY;
	BlockCipherParam.pbIV = DES_IV;

	BlockCipherParam.pbInput = DES_PLAINTEXT;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != TDESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(TDES_2KEY_CIPHERTEXT_CBC, Output, 5*TDES_BLOCK_SIZE))
	{
		return FAIL;
	}

	/////////////////////////////////////////////////////////////////
	BlockCipherParam.OpMode = SYM_CBC | SYM_DECRYPT | SYM_EDE2;
	BlockCipherParam.pbKey = TDES_KEY;
	BlockCipherParam.pbIV = DES_IV;

	BlockCipherParam.pbInput = TDES_2KEY_CIPHERTEXT_CBC;
	BlockCipherParam.TotalBlock = 5;
	BlockCipherParam.pbOutput = Output;

	if (SUCCESS != TDESCrypt(&BlockCipherParam))
	{
		return FAIL;
	}

	if (0 != memcmp(DES_PLAINTEXT, Output, 5*TDES_BLOCK_SIZE))
	{
		return FAIL;
	}

	return SUCCESS;
}


