#ifndef __DES_TEST_H__
#define __DES_TEST_H__

unsigned long DES_TEST( void );

 unsigned long TDES_TEST_2KEY( void );

#endif
