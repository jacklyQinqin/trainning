/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt_des.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.11.28
* Description:
* 	
* Others:		
* 
* Function List:	
*   			1.	DESCrypt
*				2.	TDESCrypt
*
* History:		
*   1. Date:			
*      Author:			
*      Modification:	Mofify the implementation and definition of DES and TDES
*
*   2. ......
\****************************************************************/
#ifndef __IS_DES_H__
#define __IS_DES_H__

#include "iscrypt.h"
#include "iscrypt_symmetric.h"

/* */
#define SYM_EDE2			0x10

unsigned char DESCrypt(BLOCKCIPHERPARAM *pBlockCipherParam);
unsigned char TDESCrypt(BLOCKCIPHERPARAM *pBlockCipherParam);


#endif
