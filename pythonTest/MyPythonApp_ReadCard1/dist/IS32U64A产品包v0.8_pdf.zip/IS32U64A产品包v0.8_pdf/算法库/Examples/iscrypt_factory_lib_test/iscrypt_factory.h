/****************************************************************\
* Copyright (C) 2005-2016 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt_factory.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.12.5
* Description:
* 	
* Others:		
* 
* Function List:	
* 
*				1. GetFactoryCode
*
* History:		
*
*   2. ......
\****************************************************************/
#ifndef	__IS_FACTORY_H__
#define __IS_FACTORY_H__


void GetFactoryCode(
	unsigned char *pbFtyCode		// out
);

#endif
