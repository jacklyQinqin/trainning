#include "iscrypt.h"
#include "iscrypt_factory.h"
#include "is32u64A.h"

int main( void )
{
	unsigned char factorycode[16];

	GetFactoryCode(factorycode);

}
