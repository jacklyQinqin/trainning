#include "iscrypt.h"
#include "iscrypt_random.h"
#include "is32u64A.h"

int main( void )
{

	unsigned char r[32];
	RandomInit();
 	GenRandom(2, r);

 	GenRandom(5, r);

 	GenRandom(32, r);

 	while (1)
 	{
 		GenRandom(32, r);
 	}

}
