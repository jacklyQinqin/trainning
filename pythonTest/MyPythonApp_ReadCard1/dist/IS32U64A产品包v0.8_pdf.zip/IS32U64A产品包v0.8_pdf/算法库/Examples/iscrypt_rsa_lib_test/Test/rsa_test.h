#ifndef __RSA_TEST_H__
#define __RSA_TEST_H__

unsigned char RSA_ENCRYPT_TEST(void);
unsigned char RSA_DECRYPT_TEST(void);
unsigned char RSA_SIGN_TEST(void);
unsigned char RSA_VERIY_TEST(void);
#endif

