/****************************************************************\
* Copyright (C) 2005-2016 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		iscrypt_rsa.c
* Author:			zh
* Version:			1.0.0.0
* Date:				2018.12.3
* Description:
*					Operations about RSA
* Function List:
*					1.	RSASign
*					2.	RSAVerify 
* 				3.  RSAEncrypt
*					4.	RSADecrypt
* History:
* 		<  author  >    <  date  >    <  version  >    <  description  >
*
\****************************************************************/
#ifndef __IS_RSA_H__
#define __IS_RSA_H__

#include "iscrypt.h"

typedef struct Struct_RSAPrivateKeyCRT
{
	unsigned char *n;
	/* Prime1 */
	unsigned char *p;
	/* Prime2 */
	unsigned char *q;
	/* Prime1 Exponent */
	unsigned char *dP;
	/* Prime2 Exponent */
	unsigned char *dQ;
	/* Coefficient */
	unsigned char *qInv;


}RSAPRIVATEKEYCRT, *PRSAPRIVATEKEYCRT;



typedef struct Struct_RSAPublicKey
{

	/* Public Exponent */
	unsigned char *e;
	/* modulus */
	unsigned char *n;

}RSAPUBLICKEYCTX, *PRSAPUBLICKEYCTX;

unsigned char RSAEncrypt(unsigned long bitlen,RSAPUBLICKEYCTX *pRSAPubKey,unsigned char *pbData);
unsigned long RSAVerify(unsigned long bitlen,RSAPUBLICKEYCTX *pRSAPubKey,unsigned char *signature,unsigned char *digest);
unsigned char RSASign(unsigned long bitlen,RSAPRIVATEKEYCRT *pRSAPriKey,unsigned char *pbData);
unsigned char RSADecrypt(unsigned long bitlen,RSAPRIVATEKEYCRT *pRSAPriKey,unsigned char *pbData);

#endif
