/****************************************************************\
* Copyright (C) 2005-2015 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:
* Author:
* Version:
* Date:
* Description:
*
* Function List:
*   				1. ......
*
* History:
* 		<  author  >    <  date  >    <  version  >    <  description  >
*		       	 
*
\****************************************************************/
#include "iscrypt.h"
#include "Test\rsa_test.h"
#include "iscrypt_random.h"

void							*HdxaPointer 								__attribute__((at(0x000d0f80)));
int main( void )
{
	unsigned char ret;

	RandomInit();
	ret = RSA_ENCRYPT_TEST();
	while (ret != SUCCESS);

	ret = RSA_DECRYPT_TEST();
	while (ret != SUCCESS);

	ret = RSA_SIGN_TEST();
	while (ret != SUCCESS);

	ret = RSA_VERIY_TEST();
	while (ret != SUCCESS);

	return 0;
	
}
