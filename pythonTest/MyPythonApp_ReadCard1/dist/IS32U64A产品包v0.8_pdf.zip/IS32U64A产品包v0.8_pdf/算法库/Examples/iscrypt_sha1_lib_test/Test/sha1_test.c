/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		sha1_test.c
* Author:			zh
* Version:			1.0.0.0
* Date:				2018.12.4
* Description:
*					Operations about test of SHA1
* Function List:
*					1.	sha1_memory
*					2.	sha1_test 
*
* History:
* 	
*		  
*
\****************************************************************/
#include <string.h>
#include "sha1_test.h"
#include "..\iscrypt.h"
#include "..\iscrypt_sha1.h"

/////////////////////////////////////////////////////////////////////

const unsigned char SHA_VECTOR[192] = 
{
	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71,	\

	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71,	\

	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71

};

/////////////////////////////////////////////////////////////////////

/****************************************************************\
* Function:			
*
* Description: 		
*
* Calls:			None
*
* Called By:		
*
* Input:
*					1. 
*					2. 
*
* Output:			
*					1. ...
*
* Return:			
*
* Others:			None
*
* Remark:	
*					1. ...		
*		
\****************************************************************/
unsigned char sha1_memory(
	const unsigned char *in,
	unsigned long len,
	unsigned char *dst
)
{
	
	if(0!=SHA1Init())
	{
			return FAIL;
	}
	if(0!=SHA1Update(in,len))
	{
			return FAIL;
	}
	if(0!=SHA1Final(dst))
	{
			return FAIL;
	}

	return SUCCESS ;
}

/****************************************************************\
* Function:			
*
* Description: 		
*
* Calls:			None
*
* Called By:		
*
* Input:
*					1. 
*					2. 
*
* Output:			
*					1. ...
*
* Return:			
*
* Others:			None
*
* Remark:	
*					1. ...		
*		
\****************************************************************/
unsigned char SHA1_TEST( void )
{

	int i;
	unsigned char tmp[20];

	static const struct {
		unsigned long len;
		const unsigned char *msg;
		unsigned char hash[20];
	}tests[] = 
	{
		{3, SHA_VECTOR,
			{
				0XA9,0X99,0X3E,0X36,0X47,0X06,0X81,0X6A,0XBA,0X3E,0X25,0X71,0X78,0X50,0XC2,0X6C,0X9C,0XD0,0XD8,0X9D
			}
		},

		{56, SHA_VECTOR,
			{
				0X84,0X98,0X3E,0X44,0X1C,0X3B,0XD2,0X6E,0XBA,0XAE,0X4A,0XA1,0XF9,0X51,0X29,0XE5,0XE5,0X46,0X70,0XF1
			}
		},

		{64, SHA_VECTOR,
			{
				0X84,0XA7,0XCF,0X23,0XA0,0X5B,0X94,0X85,0XD4,0X47,0X0C,0X01,0X93,0X00,0XEB,0X9B,0X82,0X7F,0X62,0X79
			}
		},

		{128, SHA_VECTOR,
			{
				0XA5,0X1C,0X64,0X93,0X9D,0X88,0X69,0X7D,0XE0,0XFF,0XC4,0X8E,0X94,0XC9,0XED,0X2A,0X24,0XA8,0X16,0X85
			}
		},

		{184, SHA_VECTOR,
			{
				0XF6,0XCC,0X70,0X5E,0X37,0X75,0XE2,0X28,0X3C,0XE6,0X8F,0XF7,0XD1,0XC3,0X4F,0XB3,0XDB,0X14,0X1E,0X41
			}
		}
	};


	/* */
	for (i = 0; i < 5; i++)
	{
		sha1_memory(tests[i].msg, tests[i].len, tmp);

		if (memcmp(tmp, tests[i].hash, 20))
		{
			return FAIL;
		}
	}

	return SUCCESS;
}

unsigned char sha1_perform_test( void )
{

	long len;	
	unsigned char tmp[32];
	len = 50000;

	if(0!=SHA1Init())
	{
		return FAIL;
	}

	while (len--)
	{
		if(0!=SHA1Update(SHA_VECTOR, 64))
		{
				return FAIL;
		}
		
	}
	if(0!=SHA1Final(tmp))
	{
			return FAIL;
	}
	
	return SUCCESS ;
}
