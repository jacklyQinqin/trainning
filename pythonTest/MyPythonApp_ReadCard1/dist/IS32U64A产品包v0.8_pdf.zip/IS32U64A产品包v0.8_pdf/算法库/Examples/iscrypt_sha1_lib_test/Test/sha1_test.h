/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		sha1_test.h
* Author:			zh
* Version:			1.0.0.0
* Date:				2018.12.4
* Description:
*					Operations about test of SHA1
* Function List:
*					1.	sha1_perform_test
*					2.	sha1_test 
*
* History:
* 	
*		  
*
\****************************************************************/
#ifndef __SHA1_TEST_H__
#define __SHA1_TEST_H__

unsigned char SHA1_TEST( void );

unsigned char sha1_perform_test( void );

#endif
