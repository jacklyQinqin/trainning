/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt_sha1.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.11.28
* Description:
* 	
* Others:		
* 
* Function List:	
*					1.	SHA1Init
*					2.	SHA1Update 
*					3.	SHA1Final 
*					4.	SHA1Simple
* History:		
*   1. Date:			2018.11.28
*      Author:			zh
*      Modification:	Mofify the implementation and definition of SM3
*
*   2. ......
\****************************************************************/
#ifndef __IS_SHA1_H__
#define __IS_SHA1_H__

unsigned char SHA1Init(void);
unsigned char SHA1Update(const unsigned char *buf,unsigned long len);
unsigned char SHA1Final(unsigned char *dst);
unsigned char SHA1Simple(const unsigned char *in,unsigned long len,unsigned char *dst);

#endif
