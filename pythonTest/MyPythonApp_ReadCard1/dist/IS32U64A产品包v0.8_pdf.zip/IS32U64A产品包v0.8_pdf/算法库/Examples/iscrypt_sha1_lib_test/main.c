#include "iscrypt.h"
#include "Test\sha1_test.h"
void							*HdxaPointer 								__attribute__((at(0x000d0f80)));
int main()
{
	unsigned long ret;
	
	ret = SHA1_TEST();
	while (ret != SUCCESS);

	return 0;
}
