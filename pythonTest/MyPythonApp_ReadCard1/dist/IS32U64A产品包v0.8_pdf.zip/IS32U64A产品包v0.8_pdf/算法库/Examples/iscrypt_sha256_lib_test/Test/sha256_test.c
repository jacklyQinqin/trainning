/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		sha256_test.c
* Author:			zh
* Version:			1.0.0.0
* Date:				2018.12.4
* Description:
*					Operations about test of SHA256
* Function List:
*					1.	sha256_memory
*					2.	sha256_test 
*
* History:
* 		
\****************************************************************/
#include <string.h>
#include "sha256_test.h"
#include "..\iscrypt.h"
#include "..\iscrypt_sha256.h"

/////////////////////////////////////////////////////////////////////

const unsigned char SHA_VECTOR[192] = 
{
	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71,	\

	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71,	\

	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71

};

/////////////////////////////////////////////////////////////////////

/****************************************************************\
* Function:			
*
* Description: 		
*
* Calls:			None
*
* Called By:		
*
* Input:
*					1. 
*					2. 
*
* Output:			
*					1. ...
*
* Return:			
*
* Others:			None
*
* Remark:	
*					1. ...		
*		
\****************************************************************/
unsigned char sha256_memory(
	const unsigned char *in,
	unsigned long len,
	unsigned char *dst
)
{
	if(0!=SHA256Init())
	{
			return FAIL;
	}
	if(0!=SHA256Update(in,len))
	{
			return FAIL;
	}
	if(0!=SHA256Final(dst))
	{
			return FAIL;
	}

	return SUCCESS ;

}

/****************************************************************\
* Function:			
*
* Description: 		
*
* Calls:			None
*
* Called By:		
*
* Input:
*					1. 
*					2. 
*
* Output:			
*					1. ...
*
* Return:			
*
* Others:			None
*
* Remark:	
*					1. ...		
*		
\****************************************************************/
unsigned char SHA256_TEST( void )
{

	int i;
	unsigned char tmp[32];

	static const struct {
		unsigned long len;
		const unsigned char *msg;
		unsigned char hash[32];
	}tests[] = 
	{
		{3, SHA_VECTOR,
			{
				0XBA,0X78,0X16,0XBF,0X8F,0X01,0XCF,0XEA,0X41,0X41,0X40,0XDE,0X5D,0XAE,0X22,0X23,0XB0,0X03,0X61,0XA3,0X96,0X17,0X7A,0X9C,0XB4,0X10,0XFF,0X61,0XF2,0X00,0X15,0XAD
			}
		},

		{56, SHA_VECTOR,
			{
				0X24,0X8D,0X6A,0X61,0XD2,0X06,0X38,0XB8,0XE5,0XC0,0X26,0X93,0X0C,0X3E,0X60,0X39,0XA3,0X3C,0XE4,0X59,0X64,0XFF,0X21,0X67,0XF6,0XEC,0XED,0XD4,0X19,0XDB,0X06,0XC1
			}
		},

		{64, SHA_VECTOR,
			{
				0X9A,0XA1,0X40,0X49,0X29,0X53,0X90,0XEE,0X20,0XDF,0X14,0X13,0XCC,0X7F,0X7D,0X07,0XA0,0XF6,0XFA,0X36,0X9D,0X07,0XB9,0X38,0X82,0XF1,0X97,0X9B,0XA5,0XE9,0X42,0XDE
			}
		},

		{128, SHA_VECTOR,
			{
				0XDA,0X77,0XE7,0XEB,0X40,0XB7,0XB8,0X94,0X88,0X84,0XA7,0X1B,0X43,0XA8,0X6C,0X1B,0X1C,0XCD,0XF5,0X1C,0X25,0X5E,0X8C,0X83,0XC8,0X08,0XF1,0XE0,0X06,0X0A,0XCB,0X83
			}
		},

		{184, SHA_VECTOR,
			{
				0XC5,0XB8,0X88,0X71,0X88,0X64,0X3D,0X00,0X1E,0XF0,0X80,0X5B,0X1B,0X64,0XEF,0XA7,0X4A,0XDF,0X8A,0XDC,0XA8,0X6C,0X85,0XB9,0X9B,0X1A,0X68,0X5D,0X50,0XD7,0XAA,0XB5
			}
		}
	};


	/* */
	for (i = 0; i < 5; i++)
	{
		sha256_memory(tests[i].msg, tests[i].len, tmp);

		if (memcmp(tmp, tests[i].hash, 32))
		{
			return FAIL;
		}
	}

	return SUCCESS;
}

unsigned char sha256_perform_test( void )
{

	long len;	
	unsigned char tmp[32];
	len = 50000;

	if(0!=SHA256Init())
	{
		return FAIL;
	}

	while (len--)
	{
		if(0!=SHA256Update(SHA_VECTOR, 64))
		{
				return FAIL;
		}
		
	}
	if(0!=SHA256Final(tmp))
	{
			return FAIL;
	}
	
	return SUCCESS ;
	
}

