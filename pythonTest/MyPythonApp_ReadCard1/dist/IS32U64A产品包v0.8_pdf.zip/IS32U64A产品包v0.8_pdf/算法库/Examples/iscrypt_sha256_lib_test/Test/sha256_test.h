/****************************************************************\
* Copyright (C) 2005-2012 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	sha256_test.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.12.4
* Description:
* 	
* Others:		
* 
* Function List:	
*					1.	sha256_test 
*
* History:		
*   1. Date:	
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef __SHA256_TEST_H__
#define __SHA256_TEST_H__

unsigned char SHA256_TEST( void );

unsigned char sha256_perform_test( void );

#endif
