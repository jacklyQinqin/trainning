#include "iscrypt.h"
#include "Test\sha256_test.h"
void							*HdxaPointer 								__attribute__((at(0x000d0f80)));
int main()
{
	unsigned long ret;
	


	ret = SHA256_TEST();
	while (ret != SUCCESS);
    

    
	return 0;
}
