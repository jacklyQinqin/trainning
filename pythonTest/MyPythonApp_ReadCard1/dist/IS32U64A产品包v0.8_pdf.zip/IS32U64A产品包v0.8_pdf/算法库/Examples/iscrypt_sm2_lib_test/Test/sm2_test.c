#include "string.h"
#include "sm2_test.h"
#include "../iscrypt.h"
#include "../iscrypt_sm2.h"

/////////////////////////////////////////////////////////////////
unsigned char space_for_test[1024];

const unsigned char SM2PublicKey[65] = 
{
		0x04,
    0X09,0XF9,0XDF,0X31,0X1E,0X54,0X21,0XA1,0X50,0XDD,0X7D,0X16,0X1E,0X4B,0XC5,0XC6,
    0X72,0X17,0X9F,0XAD,0X18,0X33,0XFC,0X07,0X6B,0XB0,0X8F,0XF3,0X56,0XF3,0X50,0X20,
    0XCC,0XEA,0X49,0X0C,0XE2,0X67,0X75,0XA5,0X2D,0XC6,0XEA,0X71,0X8C,0XC1,0XAA,0X60,
    0X0A,0XED,0X05,0XFB,0XF3,0X5E,0X08,0X4A,0X66,0X32,0XF6,0X07,0X2D,0XA9,0XAD,0X13
};

const unsigned char SM2PrivateKey[32] = 
{
	0X39,0X45,0X20,0X8F,0X7B,0X21,0X44,0XB1,0X3F,0X36,0XE3,0X8A,0XC6,0XD3,0X9F,0X95,    \
    0X88,0X93,0X93,0X69,0X28,0X60,0XB5,0X1A,0X42,0XFB,0X81,0XEF,0X4D,0XF7,0XC5,0XB8	
};

// "encryption standard"
const unsigned char SM2Plaintext[] = 
{
    0X65,0X6E,0X63,0X72,0X79,0X70,0X74,0X69,0X6F,0X6E,0X20,0X73,0X74,0X61,0X6E,0X64,    \
    0X61,0X72,0X64
};

// "message digest";
const unsigned char SM2Digest[32] = 
{
    0XF0,0XB4,0X3E,0X94,0XBA,0X45,0XAC,0XCA,0XAC,0XE6,0X92,0XED,0X53,0X43,0X82,0XEB,    \
    0X17,0XE6,0XAB,0X5A,0X19,0XCE,0X7B,0X31,0XF4,0X48,0X6F,0XDF,0XC0,0XD2,0X86,0X40
};

/////////////////////////////////////////////////////////////////

unsigned char SM2_GENERATE_KEY_TEST( void )
{
		SM2PUBLICKEYCTX PubKey;
		SM2PRIVATEKEYCTX PriKey;

		PubKey.xy = space_for_test;
		PriKey.d =space_for_test+65;
		//���������Կ��
		if(0!=SM2GenKeyPair(&PubKey,&PriKey,0x00))
		{
				return FAIL;
		}
		memcpy(space_for_test+65,SM2PrivateKey,32);
		PriKey.d = space_for_test+65;
		//�ⲿ����˽Կ��������Կ
		if(0!=SM2GenKeyPair(&PubKey,&PriKey,0x01))
		{
				return FAIL;
		}
		if(memcmp(SM2PublicKey,space_for_test,65)!=0)
		{
				return FAIL;
		}
		return SUCCESS;
}

unsigned char SM2_SIGN_VERIFY_TEST( void )
{
		SM2PUBLICKEYCTX PubKey;
		SM2PRIVATEKEYCTX PriKey;
		SM2SIGNATURE signature;
	
		memcpy(space_for_test+65,SM2PrivateKey,32);
		PriKey.d = space_for_test+65;

		signature.rs = space_for_test+97;
		
		if(0!=SM2Sign(&PriKey,(unsigned char *)SM2Digest,&signature))
		{
				return FAIL;
		}
		memcpy(space_for_test,SM2PublicKey,65);
		PubKey.xy = space_for_test;
		if(0!=	SM2Verify(&PubKey,(unsigned char *)SM2Digest,&signature))
		{
				return FAIL;
		}
		return SUCCESS;
}

unsigned char SM2_ENCRYPT_DECRYPT_TEST( void )
{
		SM2PUBLICKEYCTX PubKey;
		SM2PRIVATEKEYCTX PriKey;
		SM2PLAINTEXT pPlaintext;
		SM2CIPHERTEXT ciper;
		memcpy(space_for_test+65,SM2PrivateKey,32);
		PriKey.d = space_for_test+65;
		memcpy(space_for_test,SM2PublicKey,65);
		PubKey.xy = space_for_test;
		
		memcpy(space_for_test+386,SM2Plaintext,19);
		pPlaintext.pd = space_for_test+386;
		pPlaintext.len =19;
		ciper.c = space_for_test+386;
		
		if(0!=	SM2Encrypt(&PubKey,&pPlaintext,&ciper))
		{
				return FAIL;
		}
		ciper.len = 19; //ʵ�����ĳ��ȼ�C2����
		pPlaintext.pd =space_for_test+386;
		if(0!=SM2Decrypt(&PriKey,&ciper,&pPlaintext))
		{
				return FAIL;
		}
		if(memcmp(SM2Plaintext,space_for_test+386,19)!=0)
		{
				return FAIL;
		}
		return SUCCESS;
}

unsigned char SM2_GET_Z_TEST( void )
{
    unsigned char ZA[32];
    SM2PUBLICKEYCTX PubKey;
	unsigned char SelfID[] = 
	{
		// SELF ID
		0X31,0X32,0X33,0X34,0X35,0X36,0X37,0X38,0X31,0X32,0X33,0X34,0X35,0X36,0X37,0X38
	}; 
    
    unsigned char ZA_TRUE[] = 
    {
        0XB2,0XE1,0X4C,0X5C,0X79,0XC6,0XDF,0X5B,0X85,0XF4,0XFE,0X7E,0XD8,0XDB,0X7A,0X26,
        0X2B,0X9D,0XA7,0XE0,0X7C,0XCB,0X0E,0XA9,0XF4,0X74,0X7B,0X8C,0XCD,0XA8,0XA4,0XF3    
    };
    
    memcpy(space_for_test,SM2PublicKey,65);
		PubKey.xy = space_for_test;
		if(0!=SM2GetZ(&PubKey,SelfID,16,ZA))
		{
				return FAIL;
		}
 
    
    if (memcmp(ZA, ZA_TRUE, 32))
    {
        return FAIL;
    }
    
    return SUCCESS;
}

unsigned char SM2_PRE_SIGN_VERIFY_TEST( void )
{
		SM2PUBLICKEYCTX PubKey;
		SM2PRIVATEKEYCTX PriKey;
		SM2SIGNATURE signature;
		unsigned char plain_1[19] ={
			0X65,0X6E,0X63,0X72,0X79,0X70,0X74,0X69,0X6F,0X6E,0X20,0X73,0X74,0X61,0X6E,0X64,
			0X61,0X72,0X64};
		unsigned char SelfID[] = 
		{
			// SELF ID
			0X31,0X32,0X33,0X34,0X35,0X36,0X37,0X38,0X31,0X32,0X33,0X34,0X35,0X36,0X37,0X38
		}; 
		memcpy(space_for_test+65,SM2PrivateKey,32);
		PriKey.d = space_for_test+65;
		memcpy(space_for_test,SM2PublicKey,65);
		PubKey.xy = space_for_test;
		signature.rs = space_for_test+97;
		if(0!=SM2PreSign(&PriKey,&PubKey,SelfID,16,plain_1,19,&signature))
		{
				return FAIL;
		}
		if(0!=SM2PreVerify(&PubKey,SelfID,16,plain_1,19,&signature))
		{
				return FAIL;
		}
		return SUCCESS;
}

