#ifndef __IS_SM2_TEST_H__
#define __IS_SM2_TEST_H__

unsigned char SM2_GENERATE_KEY_TEST( void );

unsigned char SM2_ENCRYPT_DECRYPT_TEST( void );

unsigned char SM2_SIGN_VERIFY_TEST( void );

unsigned char SM2_GET_Z_TEST( void );

unsigned char SM2_PRE_SIGN_VERIFY_TEST( void );

#endif
