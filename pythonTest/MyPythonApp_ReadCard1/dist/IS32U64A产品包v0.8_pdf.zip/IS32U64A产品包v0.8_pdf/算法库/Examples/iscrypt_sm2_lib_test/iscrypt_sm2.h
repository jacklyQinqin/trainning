/****************************************************************\
* Copyright (C) 2005-2016 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		iscrypt_sm2.h
* Author:			zh      
* Version:			1.0.0.0        
* Date:				2018.11.30
* Description:    
* 					1. Relative Function with SM2
*														  	
* Others:		
*					None
*         
* Function List:                
*   				1. 
*
* History:        
*                 
*   1. Date:			
*      Author:			
*      Modification:	Mofify the implementation and definition of SM2
*
*   2. ......
\****************************************************************/
#ifndef __IS_SM2_H__
#define __IS_SM2_H__

#include "iscrypt.h"

typedef struct Struct_SM2_PubKey
{
	// As the name, point to the coordinate 
	unsigned char *xy;

}SM2PUBLICKEYCTX;

typedef struct Struct_SM2_PriKey
{
	unsigned char *d;

}SM2PRIVATEKEYCTX;


typedef struct Struct_BigInteger
{
	// Point to the data
	unsigned char *pd;

	// The length of above data
	unsigned long len;

}BIGINTEGER, SM2PLAINTEXT, IDINFO;


typedef struct Struct_SM2_Ciphertext
{
	// C1��C3��C2 -- The true ciphertext.
	unsigned char *c;
	// The length of above data
	unsigned long len;

}SM2CIPHERTEXT;


typedef struct Struct_SM2_Signature
{
	// As the name
	unsigned char *rs;

}SM2SIGNATURE;

unsigned char SM2GenKeyPair(SM2PUBLICKEYCTX *pSM2PubKey,SM2PRIVATEKEYCTX *pSM2PriKey,unsigned char PriKey_Option);
unsigned char SM2Encrypt(SM2PUBLICKEYCTX *pSM2PubKey,SM2PLAINTEXT    *pPlaintext,SM2CIPHERTEXT   *pCiphertext);
unsigned char SM2Decrypt(SM2PRIVATEKEYCTX *pSM2PriKey,SM2CIPHERTEXT *pCiphertext,SM2PLAINTEXT  *pPlaintext);
unsigned char SM2Sign(SM2PRIVATEKEYCTX *pSM2Prikey,unsigned char *pDigest,SM2SIGNATURE *pSignature);
unsigned char SM2Verify(SM2PUBLICKEYCTX *pSM2PubKey,unsigned char *pDigest,SM2SIGNATURE *pSignature);
unsigned char SM2GetZ(SM2PUBLICKEYCTX *pSM2PubKey,unsigned char *pID,unsigned long IDLen,unsigned char *pZ);
unsigned char SM2PreSign(SM2PRIVATEKEYCTX *pSM2Prikey,SM2PUBLICKEYCTX *pSM2PubKey,unsigned char *pID,unsigned long IDLen,unsigned char *msg,unsigned long msglen,SM2SIGNATURE *pSignature);
unsigned char SM2PreVerify(SM2PUBLICKEYCTX *pSM2PubKey,unsigned char *pID,unsigned long IDLen,unsigned char *msg,unsigned long msglen,SM2SIGNATURE *pSignature);



#endif

