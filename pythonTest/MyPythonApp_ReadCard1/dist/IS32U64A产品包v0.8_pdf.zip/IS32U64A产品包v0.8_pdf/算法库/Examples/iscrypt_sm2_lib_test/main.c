#include "iscrypt.h"
#include "Test\sm2_test.h"
#include "iscrypt_random.h"
void							*HdxaPointer 								__attribute__((at(0x000d0f80)));
int main( void )
{
	unsigned char ret;
	RandomInit();
	ret = SM2_GENERATE_KEY_TEST();
	while (ret != SUCCESS);

	////////////////////////////////////////////////////////////
	ret = SM2_SIGN_VERIFY_TEST();
	while (ret != SUCCESS);
		
	////////////////////////////////////////////////////////////
	ret = SM2_ENCRYPT_DECRYPT_TEST();
	while (ret != SUCCESS);

	ret = SM2_GET_Z_TEST();
	while (ret != SUCCESS);
	
	ret = SM2_PRE_SIGN_VERIFY_TEST();
	while (ret != SUCCESS);

  return 0;
}
