/****************************************************************\
* Copyright (C) 2005-2012 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		sm3_test.c
* Author:			zh
* Version:			1.0.0.0
* Date:				2018.12.3
* Description:
*					Operations about test of SM3
* Function List:
*					1.	sm3_memory
*					2.	sm3_test 
*
* History:
\****************************************************************/
#include <string.h>
#include "sm3_test.h"

#include "..\iscrypt.h"
#include "..\iscrypt_sm3.h"


/////////////////////////////////////////////////////////////////////

const unsigned char SM3_VECTOR[192] = 
{
	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71,	\

	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71,	\

	0X61,0X62,0X63,0X64,0X62,0X63,0X64,0X65,	\
	0X63,0X64,0X65,0X66,0X64,0X65,0X66,0X67,	\
	0X65,0X66,0X67,0X68,0X66,0X67,0X68,0X69,	\
	0X67,0X68,0X69,0X6A,0X68,0X69,0X6A,0X6B,	\
	0X69,0X6A,0X6B,0X6C,0X6A,0X6B,0X6C,0X6D,	\
	0X6B,0X6C,0X6D,0X6E,0X6C,0X6D,0X6E,0X6F,	\
	0X6D,0X6E,0X6F,0X70,0X6E,0X6F,0X70,0X71,	\
	0X6E,0X6F,0X70,0X71,0X6E,0X6F,0X70,0X71

};

/////////////////////////////////////////////////////////////////////

/****************************************************************\
* Function:			sm3_memory
*
* Description: 		
*
* Calls:			
*					1.	SM3Init
*					2.	SM3Update
*					2.	SM3Final
*
* Called By:		
*
* Input:
*					in
* 
*					len 
*
*
* Output:			
*					dst
*
* Return:			
*					None
*
* Others:			
*					None
*
* Remark:	
*					1. ...		
*		
\****************************************************************/
unsigned char sm3_memory(
	const unsigned char *in,
	unsigned long len,
	unsigned char *dst
)
{
	if(0!=SM3Init())
	{
			return FAIL;
	}
	if(0!=SM3Update(in,len))
	{
			return FAIL;
	}
	if(0!=SM3Final(dst))
	{
			return FAIL;
	}
	return SUCCESS;
}

/****************************************************************\
* Function:			SM3_TEST
*
* Description: 		
*
* Calls:			
*					1.	sm3_memory
*					2.	memcmp
*
* Called By:		
*
* Input:
*					None
*
* Output:			
*					None
*
* Return:			
*					SUCCESS
*					FAIL
*
* Others:			
*					None
*
* Remark:	
*					1. ...		
*		
\****************************************************************/
unsigned char SM3_TEST( void )
{

	int i;
	unsigned char tmp[32];

	static const struct {
		unsigned long len;
		const unsigned char *msg;
		unsigned char hash[32];
	}tests[] = 
	{
		{3, SM3_VECTOR,
			{
				0X66,0XC7,0XF0,0XF4,0X62,0XEE,0XED,0XD9,0XD1,0XF2,0XD4,0X6B,0XDC,0X10,0XE4,0XE2,0X41,0X67,0XC4,0X87,0X5C,0XF2,0XF7,0XA2,0X29,0X7D,0XA0,0X2B,0X8F,0X4B,0XA8,0XE0
			}
		},

		{56, SM3_VECTOR,
			{
				0X63,0X9B,0X6C,0XC5,0XE6,0X4D,0X9E,0X37,0XA3,0X90,0XB1,0X92,0XDF,0X4F,0XA1,0XEA,0X07,0X20,0XAB,0X74,0X7F,0XF6,0X92,0XB9,0XF3,0X8C,0X4E,0X66,0XAD,0X7B,0X8C,0X05
			}
		},

		{64, SM3_VECTOR,
			{
				0X25,0XE3,0X41,0X3D,0X11,0X9C,0X66,0X7A,0X80,0X2D,0X51,0X58,0X6F,0X1E,0X44,0X3D,0XE9,0XF9,0XCD,0XAE,0X12,0X32,0X7A,0XF9,0X74,0XEF,0XF7,0XC5,0XE8,0X30,0X15,0X02
			}
		},

		{128, SM3_VECTOR,
			{
				0X06,0XFA,0XCB,0X95,0XD3,0X29,0X0F,0X56,0XC1,0XB4,0X07,0X01,0X8B,0X5A,0XF2,0XEF,0XA1,0X4B,0X4B,0XE6,0X16,0X9A,0X67,0X21,0XDE,0XB1,0X41,0XBC,0XE6,0XB4,0XA5,0X45
			}
		},

		{184, SM3_VECTOR,
			{
				0X59,0XDA,0X36,0X7F,0X78,0X07,0X6A,0XA4,0X04,0X37,0X9A,0XEA,0X0E,0X84,0X4D,0X61,0X4C,0XCE,0X94,0X8F,0X63,0XA6,0X29,0X68,0X3F,0X67,0X8F,0X5D,0XE4,0XE0,0X80,0X6F
			}
		}
	};


	/* */
	for (i = 0; i < 5; i++)
	{
		sm3_memory(tests[i].msg, tests[i].len, tmp);

		if (memcmp(tmp, tests[i].hash, 32))
		{
			return FAIL;
		}
	}

	return SUCCESS;
}

unsigned char SM3_PERFORM_TEST( void )
{

	long len;	
	unsigned char tmp[32];
	if(0!=SM3Init())
	{
			return FAIL;
	}
	len =2000;
	while (len--)
	{
			if(0!=SM3Update(SM3_VECTOR,64))
			{
					return FAIL;
			}
	}
	if(0!=SM3Final(tmp))
	{
			return FAIL;
	}
	return SUCCESS;
}

