/****************************************************************\
* Copyright (C) 2005-2012 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	sm3_test.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.12.3
* Description:
* 	
* Others:		
* 
* Function List:	
*					1.	sm3_test 
*
* History:		
*   1. Date:	
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef __SM3_TEST_H__
#define __SM3_TEST_H__

unsigned char SM3_TEST( void );

unsigned char SM3_PERFORM_TEST( void );

#endif
