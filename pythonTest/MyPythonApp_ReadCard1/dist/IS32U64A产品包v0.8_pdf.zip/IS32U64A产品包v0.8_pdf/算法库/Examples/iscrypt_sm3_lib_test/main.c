#include "iscrypt.h"
#include "Test\sm3_test.h"

void							*HdxaPointer 								__attribute__((at(0x000d0f80)));
int main()
{
	unsigned long ret;
	

	
	ret = SM3_TEST();
	while (ret != SUCCESS);
	
	SM3_PERFORM_TEST();

	return 0;
}
