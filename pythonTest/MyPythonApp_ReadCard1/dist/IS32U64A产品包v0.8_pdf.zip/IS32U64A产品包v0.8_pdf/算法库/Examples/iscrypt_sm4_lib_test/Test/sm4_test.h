#ifndef __SM4_TEST_H__
#define __SM4_TEST_H__

unsigned long SM4_TEST( void );

#endif
