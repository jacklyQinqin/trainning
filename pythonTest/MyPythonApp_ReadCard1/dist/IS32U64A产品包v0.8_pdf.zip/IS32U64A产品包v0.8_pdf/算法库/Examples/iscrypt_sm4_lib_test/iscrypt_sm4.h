/****************************************************************\
* Copyright (C) 2005-2016 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt_sm4.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.11.28
* Description:
* 	
* Others:		
* 
* Function List:	
*   			1. SM4Crypt
*
* History:		
*   1. Date:			2018.11.28
*      Author:			zh
*      Modification:	Mofify the implementation and definition of SM4
*
*   2. ......
\****************************************************************/
#ifndef __IS_SM4_H__
#define __IS_SM4_H__

#include "iscrypt_symmetric.h"
unsigned char SM4Crypt(BLOCKCIPHERPARAM *pBlockCipherParam);

#endif
