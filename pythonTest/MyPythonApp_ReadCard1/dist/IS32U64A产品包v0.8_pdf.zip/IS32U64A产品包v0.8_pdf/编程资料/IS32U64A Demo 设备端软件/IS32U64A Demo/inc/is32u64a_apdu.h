/************************************************************/
/*				 		*/
/*				All Right Reserved							*/
/*�ļ����ƣ�IS32U64A_apdu.h								*/
/*��    �ߣ�												*/
/*��ǰ�汾��V1.0.0											*/
/*��    �ڣ�2018-10-16										*/
/*����������	   											*/
/*		    ���ļ����ڶ���IS32U512AоƬ�����Ĵ����ĵ�ַ    */
/*�޸����ݣ���������										*/
/************************************************************/
#ifndef __IS32U64A_APDU_H__
#define __IS32U64A_APDU_H__
#include "is32u64a_typesmacro.h"
#include "iscrypt_sm2.h"
#include "iscrypt_rsa.h"
#define CLA		*(pApduBuff+0)
#define INS		*(pApduBuff+1)
#define P1		*(pApduBuff+2)
#define P2		*(pApduBuff+3)
#define P3		*(pApduBuff+4)
#define VOLTAGE1 	*(pApduBuff+8)
#define VOLTAGE2	*(pApduBuff+7)


#define BUFFER_MAX_LEN      1430
//
//
#define RSA_E_OFFSET        0
#define RSA_N_OFFSET        4
#define RSA_D_OFFSET        (4+256)
#define RSA_P_OFFSET        (4+256)
#define RSA_Q_OFFSET        (4+256+128)
#define RSA_DP_OFFSET       (4+256+128+128)
#define RSA_DQ_OFFSET       (4+256+128+128+128)
#define RSA_QINV_OFFSET     (4+256+128+128+128+128)
#define RSA_DATA_OFFSET    (4+256+128+128+128+128+128)

#define SM2_GX_OFFSET             0
#define SM2_GY_OFFSET             33
#define SM2_D_OFFSET              65

#define SM2_CIPHER_X_OFFSET       97
#define SM2_CIPHER_Y_OFFSET       130
#define SM2_CIPHER_HASH_OFFSET    162
#define SM2_CIPHER_CIPHER_OFFSET  194
#define SM2_PLAIN_OFFSET          816 //û��

#define SM2_DIGEST_OFFSET         97
#define SM2_SIGNATURE_R_OFFSET    129
#define SM2_SIGNATURE_S_OFFSET    161 


#ifndef __APDU_GLOBAL
#define APDU_EXT extern
#else
#define APDU_EXT
#endif
APDU_EXT UINT32 bitlen; 
APDU_EXT UINT32 rsakeygetstatus;
APDU_EXT UINT8 keybuffer[256] __attribute__((at(0x000d013c)));
APDU_EXT UINT8 buffer[BUFFER_MAX_LEN]  __attribute__((at(0x000d023c)));
APDU_EXT RSAPRIVATEKEYCRT RSAPriKeyCRT;
APDU_EXT RSAPUBLICKEYCTX  RSAPubKeyCTX;


APDU_EXT SM2PUBLICKEYCTX  SM2PubKeyCTX;
APDU_EXT SM2PRIVATEKEYCTX SM2PriKeyCTX;
APDU_EXT SM2CIPHERTEXT    SM2CipherText1;
APDU_EXT SM2PLAINTEXT     SM2PlainText1;
APDU_EXT SM2SIGNATURE     SM2Signature1;
APDU_EXT unsigned char gtimecount;
APDU_EXT void U8ToU32(UINT8 *src,UINT32 *des,UINT32 bytelen);
APDU_EXT void U32ToU8(UINT32 *src,UINT8 *des,UINT8 bytelen);
APDU_EXT void WriteSeed( void );
APDU_EXT UINT32 ApduDeal(UINT8 *pApduBuff);
#endif
