/************************************************************/
/*				 		*/
/*				All Right Reserved							*/
/*�ļ����ƣ�IS32U256B_crc.h								*/
/*��    �ߣ�												*/
/*��ǰ�汾��V1.0.0											*/
/*��    �ڣ�2012-08-26										*/
/*����������	   											*/
/*		                                                    */
/*�޸����ݣ���������										*/
/************************************************************/

#ifndef __IS32U256B_CRC_H__
#define __IS32U256B_CRC_H__

typedef struct 
{
	UINT32 CRCWidth;	
	UINT32 OutputNot;
	UINT32 OutputRev;
	UINT32 InputRev;
}CRCInitTypeDef;

#define CRCWidth32		0x00
#define CRCWidth16      0x10
#define CRCWidth8       0x20

#define Outputnot		0x08
#define Output			0x00
#define Outputrev		0x04
#define Inputrev		0x02
#define Input			0x00

#ifndef CRC_GLOBAL
#define CRC_EXT		extern
#else
#define CRC_EXT
#endif

CRC_EXT void CRCInit(CRCInitTypeDef *CRCInitStruct);
CRC_EXT void CRCOn(void);
CRC_EXT void CRCLoadData(UINT32 data);
CRC_EXT void CRCIVData(UINT32 data);
CRC_EXT UINT16 CRCResult(void);

#endif
