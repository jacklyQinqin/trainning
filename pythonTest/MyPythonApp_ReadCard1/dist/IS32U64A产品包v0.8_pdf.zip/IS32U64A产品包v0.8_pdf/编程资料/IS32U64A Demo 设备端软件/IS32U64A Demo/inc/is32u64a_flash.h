/************************************************************/
/*										*/
/*				All Right Reserved							*/
/*�ļ����ƣ�IS32U64A_flash.h								*/
/*��    �ߣ�												*/
/*��ǰ�汾��V1.0.0											*/
/*��    �ڣ�2018-10-31										*/
/*����������	   											*/
/*�޸����ݣ���������										*/
/************************************************************/

#ifndef __IS32U64A_FLASH_H__
#define __IS32U64A_FLASH_H__

#ifndef FLASH_GLOBAL
#define FLASH_EXT extern
#else
#define FLASH_EXT
#endif


FLASH_EXT unsigned int g_Address;
FLASH_EXT unsigned char FlashRead8(UINT8 *des,UINT32 src,UINT32 bytelen);
FLASH_EXT unsigned char  FlashWrite8(UINT32 des,UINT8 *src,UINT32 bytelen);
FLASH_EXT void FlashPageEraseKey(UINT32 address);
FLASH_EXT void FlashNPageErase(UINT32 address,unsigned int pagecount);
FLASH_EXT void ReDownload(void);

#endif
