#ifndef _IS32U512A_MAIN_H
#define _IS32U512A_MAIN_H
#include "is32u512a_usbtypes.h"
#include "is32u512a_typesmacro.h"




#ifndef _IS32U512A_MAIN_EXTERN
	#define _IS32U512A_MAIN_EXTERN extern
#else
	#define _IS32U512A_MAIN_EXTERN 
#endif

_IS32U512A_MAIN_EXTERN void write (UINT32 addr, UINT32 data);
_IS32U512A_MAIN_EXTERN void writebyte (UINT32 addr, UINT8 data);
_IS32U512A_MAIN_EXTERN UINT32 read (UINT32 addr);
_IS32U512A_MAIN_EXTERN UINT8 readbyte (UINT32 addr);
_IS32U512A_MAIN_EXTERN void int_enable(UINT32 int_num);
_IS32U512A_MAIN_EXTERN void int_disable(UINT32 int_num);
_IS32U512A_MAIN_EXTERN void ipclk_enable(UINT32 ip_num);
_IS32U512A_MAIN_EXTERN void OSC_sysclkinit(void);
_IS32U512A_MAIN_EXTERN void PLL_sysclkinit(void);
_IS32U512A_MAIN_EXTERN	void PHY_sysclkinit(void);
#endif 
