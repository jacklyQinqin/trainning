#ifndef _IS32U64A_SYS_INIT_H
#define _IS32U64A_SYS_INIT_H


#ifndef _IS32U64A_SYS_EXTERN
	#define _IS32U64A_SYS_EXTERN extern
#else
	#define _IS32U64A_SYS_EXTERN 
#endif

_IS32U64A_SYS_EXTERN void GpioConfiguration(void);
_IS32U64A_SYS_EXTERN void SysFuntionInit(void);

#endif 
