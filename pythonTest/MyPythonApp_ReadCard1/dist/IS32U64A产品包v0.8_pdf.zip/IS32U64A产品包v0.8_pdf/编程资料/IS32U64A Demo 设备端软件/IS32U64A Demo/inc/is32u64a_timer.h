/************************************************************/
/*				Copy Right (C)���������Ű��Ƽ����޹�˾		*/
/*				All Right Reserved							*/
/*�ļ����ƣ�IS32U64A_timer.h								*/
/*��    �ߣ�												*/
/*��ǰ�汾��V1.0.0											*/
/*��    �ڣ�2018-10-16										*/
/*����������	   											*/
/*		                                                    */
/*�޸����ݣ���������										*/
/************************************************************/

#ifndef __IS32U64A_TIMER_H__
#define __IS32U64A_TIMER_H__

typedef struct 
{
	UINT8 TimerMode;
	UINT8 ExtPluseCnt;
	UINT8 TimerPre;
	UINT8 TimerSize;
	UINT8 OneShotCnt;

	UINT32 TimerLoad;

}TimerInitTypeDef;

#define Timer1                0x000F0800
#define Timer2                0x000F0820


#define TimerModePeriodic     (0x40)
#define TimerModeFreeRun      (0x00)

#define TimerExtPluseCnt      (0x10)
#define TimerPclkCnt          (0x00)

#define TimerPre1             (0x00)
#define TimerPre16            (0x04)
#define TimerPre256           (0x08)
 
#define TimerSize32           (0x02)
#define TimerSize16           (0x00)

#define TimerOneShotCnt       (0x01)
#define TimerLoopCnt          (0x00)

#ifndef TIMER_GLOBAL
#define TIMER_EXT    extern
#else
#define TIMER_EXT
#endif

TIMER_EXT void TimerOn(UINT32 TimerX);
TIMER_EXT void TimerOff(UINT32 TimerX);
TIMER_EXT void TimerInit(UINT32 TimerX,TimerInitTypeDef *TimerInitStruct);
TIMER_EXT void TimerClrIntFlag(UINT32 TimerX);
#endif

