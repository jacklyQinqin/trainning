/***************************************************\
*			 
*			 All Right Reserved
*
*�ļ����ƣ�IS32U64A_uart.h
*��    �ߣ� 
*��    ����V1.0.0
*��    �ڣ�2012.08.28
*����������
*	      ���IS32U64A������uartͨ�ŵĵײ���������
*		  ��ͷ�ļ�����
*��ʷ��¼��
*	1�� ���ڣ�
*		�汾��
*		���ߣ�
*	�޸����ݣ�
*	2��.....
\***************************************************/

#ifndef ___IS32U64A_UART_H__
#define ___IS32U64A_UART_H__

#include "is32u64a_typesmacro.h"
#include "stdio.h"
//#define IS32U64AUARTENABLE 1

typedef struct
{			   	
	UINT32 UART_RXStopBit;
	UINT32 UART_RXBitLen;
	UINT32 UART_RXParity;

	UINT32 UART_TXStopBit;
	UINT32 UART_TXBitLen;
	UINT32 UART_TXParity;

	UINT32 UART_IE;

}UARTCTRL_InitType;

#define UART_RXStopBit_1		0x0000
#define UART_RXStopBit_15		0x1000
#define UART_RXStopBit_2		0x2000

#define UART_RXBitLen_8			0x0000
#define UART_RXBitLen_7			0x0400
#define UART_RXBitLen_6			0x0800
#define UART_RXBitLen_5			0x0C00

#define UART_RXParity_NULL		0x0000
#define UART_RXParity_EVEN		0x0200
#define UART_RXParity_ODD		0x0100


#define UART_TXStopBit_1		0x0000
#define UART_TXStopBit_15		0x0020
#define UART_TXStopBit_2		0x0040

#define UART_TXBitLen_8			0x0000
#define UART_TXBitLen_7			0x0008
#define UART_TXBitLen_6			0x0010
#define UART_TXBitLen_5			0x0018

#define UART_TXParity_NULL		0x0000
#define UART_TXParity_EVEN		0x0004
#define UART_TXParity_ODD		0x0002

#define UART_IE_EN				0x0001
#define UART_IE_DIS				0x0000

#define UART1					0x0001
#define UART2					0x0002

typedef struct
{

	UINT32 AHB_Div;
	UINT32 SYS_Div;
}UARTCLK_InitType;




#define AHB_Div_0				0x00
#define AHB_Div_2				0x02

#define SYS_Div_0				0x00
#define SYS_Div_2				0x02
#define SYS_Div_4				0x04
#define SYS_Div_8				0x08

#define UART_RX_Mask			0xC0FF
#define UART_TX_Mask			0xFF81
#define UART_IE_Mask			0xFFFE
#define RX_BUSY_MASK			0x80000
#define TX_BUSY_MASK			0x100000
#define RX_INT					(0x1<<14)
#define TX_INT					(0x1<<15)
#ifndef UART_GLOBAL
#define UART_EXT	extern
#else
#define UART_EXT
#endif

UART_EXT UINT8 uartbuff[280];
UART_EXT UINT8 uart_total_len;
UART_EXT UINT8 uart_rec_count;
UART_EXT UINT8 *pData;
UART_EXT UINT8 flag;

UART_EXT UINT32 UartClkInit(UARTCLK_InitType *UARTClk_Struct);
UART_EXT void UartBaudRateInit(UARTCLK_InitType *UARTCLK_Struct,UINT32 UART_BaudRate);
UART_EXT void UartSendData(UINT8 *pData);
UART_EXT void UartReceiveData(UINT8 *pData);

UART_EXT void UARTCONInit(UARTCTRL_InitType *UARTCTRL_InitStruct);
UART_EXT void IS32U64AUartProcess();

void Uart2SendString(UINT8 *pData,unsigned int len);
void Uart1SendString(UINT8 *pData,unsigned int len);

// UART_EXT int fputc(int ch, FILE *f);
// UART_EXT int fgetc(FILE *f);

#endif
