/****************************************************************\
* Copyright (C) 2005-2012 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		iscrypt_ec_basic_operation.h
* Author:			         
* Version:			1.0.0.0        
* Date:				2012.08.29  
* Description:    
* 					1. Basic Operation About ECC
*														  	
* Others:		
*					None
*         
* Function List:                
*   				1.	SetModulusOfP
*   				2.	SetModulusOfN
*   				3.	JacobiToAffine
*   				4.	kG
*   				5.	kP
*   				6.	kP_Add_lQ
*   				7.	CheckPoint
*
* History:        
*                 
*   1. Date:
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef __IS_EC_BASIC_OP_H__
#define __IS_EC_BASIC_OP_H__

#include "iscrypt.h"

typedef struct EC_Curve_st
{
	unsigned long len;

	unsigned long p[8];
	unsigned long a[8];
	unsigned long b[8];
	unsigned long x[8];
	unsigned long y[8];
	unsigned long n[8];

	unsigned long long prho;
	unsigned long pr[8];
	unsigned long prr[8];

	unsigned long long nrho;
	unsigned long nr[8];
	unsigned long nrr[8];

	unsigned long mona[8];

	unsigned long x1[8];
	unsigned long y1[8];

	unsigned long x2[8];
	unsigned long y2[8];

	unsigned long x3[8];
	unsigned long y3[8];

}EC_CURVE; 

////////////////////////////////////////////////////////////////
void GenRandomByWordE(
	unsigned long ulRandomLen,	//	in
	unsigned long *RandomData	//	out
);

void ModExpE(
	unsigned long *exp,		//	in
	unsigned long len		//	in
);

void SetModulusOfP(const EC_CURVE *curve);

void SetModulusOfN(const EC_CURVE *curve);

void JacobiToAffine(const EC_CURVE *curve);

void kG(const EC_CURVE *curve, unsigned long *k);

void kP(const EC_CURVE *curve, unsigned long *k);

void kP_Add_lQ(const EC_CURVE *curve, unsigned long *k, unsigned long *l);

unsigned long CheckPoint(const EC_CURVE *curve);

#endif
