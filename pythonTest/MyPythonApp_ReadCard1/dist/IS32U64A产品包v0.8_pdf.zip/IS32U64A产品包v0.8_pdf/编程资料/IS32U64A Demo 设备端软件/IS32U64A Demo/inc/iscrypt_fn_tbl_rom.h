#ifndef __FN_TBL_H__
#define __FN_TBL_H__

#define FN_SBCCrypt_IDX				0

#define FN_SHA1Simple_IDX			1
#define FN_SHA1Init_IDX				2
#define FN_SHA1Update_IDX			3
#define FN_SHA1Final_IDX			4

#define FN_SHA256Simple_IDX		5
#define FN_SHA256Init_IDX			6
#define FN_SHA256Update_IDX		7
#define FN_SHA256Final_IDX		8

#define FN_SM3Simple_IDX			9
#define FN_SM3Init_IDX				10
#define FN_SM3Update_IDX			11
#define FN_SM3Final_IDX				12

#define FN_SM2KG_IDX					13
#define FN_SM2Sign_IDX				14
#define FN_SM2Verify_IDX			15
#define FN_SM2Enc_IDX					16
#define FN_SM2Dec_IDX					17

#define FN_RSASignCRT_IDX			18
#define FN_RSAVerify_IDX			19

#define	FN_SM9Pair_IDX        20
#define	FN_SM9MSKG_IDX        21 
#define	FN_SM9USKG_IDX        22 
#define FN_SM9Sign_IDX        23 
#define	FN_SM9Verify_IDX      24 
#define FN_SM9MEKG_IDX        25 
#define	FN_SM9UEKG_IDX        26 
#define	FN_SM9Enc_IDX         27 
#define	FN_SM9Dec_IDX         28 


//
extern const void * const IS_FnTbl[];

#endif
