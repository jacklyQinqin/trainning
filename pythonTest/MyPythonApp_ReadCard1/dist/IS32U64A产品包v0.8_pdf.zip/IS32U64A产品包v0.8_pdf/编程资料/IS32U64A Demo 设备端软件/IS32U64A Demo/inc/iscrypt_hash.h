/****************************************************************\
*  
* All Rights Reserved
* File Name:	iscrypt_hash.h
* Author:		 
* Version:		1.0.0.0
* Date:			2014.05.08
* Description:
* 	
* Others:		
* 
* Function List:	
*   1. ......
*
* History:		
*   1. Date:			2016.06.02
*      Author:			 
*      Modification:	Mofify the implementation and definition of HASH
*
*   2. ......
\****************************************************************/
#ifndef __IS_HASH_H__
#define __IS_HASH_H__

#ifndef __IS_COMPILE_ROM__
#include "iscrypt_fn_tbl_rom.h"
#endif

typedef struct _SHA1_STATE_  
{

	unsigned char Buf[64];
	unsigned long ulBufLen;

	unsigned long long ullMsgLen;

	unsigned long sha1[5];
	 
}SHA1STATE;

typedef struct _SHA256_STATE_  
{
	unsigned char Buf[64];
	unsigned long ulBufLen;

	unsigned long long ullMsgLen;

	unsigned long sha256[8];
	 
}SHA256STATE;

typedef struct _SHA384_STATE_  
{
	unsigned char Buf[128];
	unsigned long ulBufLen;

	unsigned long long ulMsgLenH;
	unsigned long long ulMsgLenL;

	unsigned long long sha384[8];
	 
}SHA384STATE;

typedef struct _SHA512_STATE_  
{

	unsigned char Buf[128];
	unsigned long ulBufLen;

	unsigned long long ullMsgLenH;
	unsigned long long ullMsgLenL;

	unsigned long long sha512[8];
	 
}SHA512STATE;


//////////////////////////////////////////////////////////////////////////
#ifndef __IS_COMPILE_ROM__

typedef void (* pfunc_SHA1Init)(
	SHA1STATE *state			// in
);

typedef void (* pfunc_SHA1Update)(
	SHA1STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

typedef unsigned long (* pfunc_SHA1Final)(
	SHA1STATE *state,			// in 
	unsigned char *dst			// out
);


typedef void (* pfunc_SHA256Init)(
	SHA256STATE *state			// in
);

typedef void (* pfunc_SHA256Update)(
	SHA256STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

typedef unsigned long (* pfunc_SHA256Final)(
	SHA256STATE *state,			// in 
	unsigned char *dst			// out
);


typedef void (* pfunc_SHA384Init)(
	SHA384STATE *state			// in
);

typedef void (* pfunc_SHA384Update)(
	SHA384STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

typedef unsigned long (* pfunc_SHA384Final)(
	SHA384STATE *state,			// in 
	unsigned char *dst			// out
);


typedef void (* pfunc_SHA512Init)(
	SHA512STATE *state			// in
);

typedef void (* pfunc_SHA512Update)(
	SHA512STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

typedef unsigned long (* pfunc_SHA512Final)(
	SHA512STATE *state,			// in 
	unsigned char *dst			// out
);

//////////////////////////////////////////////////////////////////////////

#define	SHA1Init		((pfunc_SHA1Init	)(IS_FnTbl[FN_SHA1_I_IDX]))
#define	SHA1Update		((pfunc_SHA1Update	)(IS_FnTbl[FN_SHA1_U_IDX]))
#define	SHA1Final		((pfunc_SHA1Final	)(IS_FnTbl[FN_SHA1_F_IDX]))

#define	SHA256Init		((pfunc_SHA256Init	)(IS_FnTbl[FN_SHA256_I_IDX]))
#define	SHA256Update	((pfunc_SHA256Update)(IS_FnTbl[FN_SHA256_U_IDX]))
#define	SHA256Final		((pfunc_SHA256Final	)(IS_FnTbl[FN_SHA256_F_IDX]))

#define	SHA384Init		((pfunc_SHA384Init	)(IS_FnTbl[FN_SHA384_I_IDX]))
#define	SHA384Update	((pfunc_SHA384Update)(IS_FnTbl[FN_SHA384_U_IDX]))
#define	SHA384Final		((pfunc_SHA384Final	)(IS_FnTbl[FN_SHA384_F_IDX]))

#define	SHA512Init		((pfunc_SHA512Init	)(IS_FnTbl[FN_SHA512_I_IDX]))
#define	SHA512Update	((pfunc_SHA512Update)(IS_FnTbl[FN_SHA512_U_IDX]))
#define	SHA512Final		((pfunc_SHA512Final	)(IS_FnTbl[FN_SHA512_F_IDX]))

#else

void SHA1Init(
	SHA1STATE *state			// in
);

void SHA1Update(
	SHA1STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

unsigned long SHA1Final(
	SHA1STATE *state,			// in 
	unsigned char *dst			// out
);


void SHA256Init(
	SHA256STATE *state			// in
);

void SHA256Update(
	SHA256STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

unsigned long SHA256Final(
	SHA256STATE *state,			// in 
	unsigned char *dst			// out
);


void SHA384Init(
	SHA384STATE *state			// in
);

void SHA384Update(
	SHA384STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

unsigned long SHA384Final(
	SHA384STATE *state,			// in 
	unsigned char *dst			// out
);


void SHA512Init(
	SHA512STATE *state			// in
);

void SHA512Update(
	SHA512STATE *state,			// in 
	const unsigned char *buf,	// in
	unsigned long len			// in
);

unsigned long SHA512Final(
	SHA512STATE *state,			// in 
	unsigned char *dst			// out
);

#endif

#endif
