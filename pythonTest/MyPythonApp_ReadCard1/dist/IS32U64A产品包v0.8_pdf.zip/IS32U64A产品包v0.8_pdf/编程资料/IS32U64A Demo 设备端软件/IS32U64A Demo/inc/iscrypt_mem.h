/****************************************************************\
* Copyright (C) 2005-2012 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	memory.h
* Author:		 
* Version:		1.0.0.0        
* Date:			2011.08.17
* Description:	
*				1. memory manage operation
*
* Others:		None
*
* Function List:
*				1. memsetw
*				2. memcpyw
*				3. memcmpw
*				4. memmovew
*				5. memrcpyw
*				6. memrcmpw
*
* History:
*   1. Date:
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef __IS_MEMORY_H__
#define __IS_MEMORY_H__

/* Function Declarations */
void * memsetw(
	unsigned long * dst, 
	unsigned long val, 
	unsigned long n
);

void * memcpyw(
	register unsigned long *dst, 
	register const unsigned long *src, 
	register unsigned long n
);

long memcmpw(
	const unsigned long *src1, 
	const unsigned long *src2, 
	unsigned long n
);

void * memmovew(
	unsigned long * dst, 
	const unsigned long * src, 
	unsigned long n
);

void * memrcpyw(
	register unsigned long *dst, 
	register const unsigned long *src, 
	register unsigned long n
);

int memrcmpw(
	const unsigned long *src1, 
	const unsigned long *src2, 
	unsigned long n
);

void * memrvsw(
	register unsigned long *dst, 
	register unsigned long n
);

#endif
