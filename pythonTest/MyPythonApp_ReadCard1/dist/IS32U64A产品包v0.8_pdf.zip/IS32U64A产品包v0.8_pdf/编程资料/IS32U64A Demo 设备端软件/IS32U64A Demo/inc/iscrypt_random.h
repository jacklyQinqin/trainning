/****************************************************************\
* Copyright (C) 2005-2016 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt_random.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.12.5
* Description:
* 	
* Others:		
* 
* Function List:	
*   			1. GenRandom
*				2. GetFactoryCode
*
* History:		
*
*   2. ......
\****************************************************************/
#ifndef	__IS_RANDOM_H__
#define __IS_RANDOM_H__

void RandomInit(void);
void GenRandom(
	unsigned int len,			// in
	unsigned char *pbRandom		// out
);


#endif
