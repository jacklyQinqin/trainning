/****************************************************************\
* Copyright (C) 2005-2012 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		iscrypt_rsa.h
* Author:			 
* Version:			1.0.0.0
* Date:				2012.07.19
* Description:
*					Operations about RSA
*
* Others:
*
* Function List:
*					1.	RSAEncrypt
*					2.	RSADecrypt 
*					3.	RSASign 
*					4.	RSAVerify 
*
* History:
*   1. Date:
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef __IS_RSA_H__
#define __IS_RSA_H__

#include "iscrypt.h"

typedef struct Struct_RSAPrivateKeyCRT
{

	/* Prime1 */
	unsigned char *p;
	/* Prime2 */
	unsigned char *q;
	/* Prime1 Exponent */
	unsigned char *dP;
	/* Prime2 Exponent */
	unsigned char *dQ;
	/* Coefficient */
	unsigned char *qInv;

}RSAPRIVATEKEYCRT, *PRSAPRIVATEKEYCRT;

typedef struct Struct_RSAPrivateKeySTD
{

	/* Prime1 */
	unsigned char *d;
	/* Prime2 */
	unsigned char *n;

}RSAPRIVATEKEYSTD, *PRSAPRIVATEKEYSTD;

#define RSAPRIVATEKEYCTX	void

typedef struct Struct_RSAPublicKey
{

	/* Public Exponent */
	unsigned char *e;
	/* modulus */
	unsigned char *n;

}RSAPUBLICKEYCTX, *PRSAPUBLICKEYCTX;


/* choice of the algorithm type */
#define RSA1024				0x00
#define RSA2048				0x01

/* type of RSA private key operation */
#define STD_TYPE			0x00
#define CRT_TYPE			0x08


/* Variable */


////////////////////////////////////////////////////////////////

/* External Function Definition */
unsigned long RSAGenKeyPair(
	unsigned long mode,				// in
	RSAPUBLICKEYCTX *pRSAPubKey,	// in, out
	RSAPRIVATEKEYCTX *pRSAPriKey	// out
);

unsigned long RSASign(
	unsigned long mode,				// in
	RSAPRIVATEKEYCTX *pRSAPriKey,	// in
	unsigned char *pulDigset		// in, out
);

unsigned long RSAVerify(
	unsigned long mode,			// in
	RSAPUBLICKEYCTX *pRSAPubKey,// in
	unsigned char *pbSignature,	// in
	unsigned char *pbDigest		// in
);

#define RSAEncrypt(mode, pRSAPubKey, pbData)	\
		RSAVerify(mode, pRSAPubKey, pbData, NULL)

#define RSADecrypt(mode, pRSAPriKey, pbData)	\
		RSASign(mode, pRSAPriKey, pbData)

#endif
