/****************************************************************\
* Copyright (C) 2018- Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:	iscrypt_sm3.h
* Author:		zh
* Version:		1.0.0.0
* Date:			2018.11.28
* Description:
* 	
* Others:		
* 
* Function List:	
*					1.	SM3Init
*					2.	SM3Update 
*					3.	SM3Final 
*					4.	Sm3
* History:		
*   1. Date:			2018.11.28
*      Author:			zh
*      Modification:	Mofify the implementation and definition of SM3
*
*   2. ......
\****************************************************************/
#ifndef __IS_SM3_H__
#define __IS_SM3_H__

unsigned char SM3Init(void);
unsigned char SM3Update(const unsigned char *buf,unsigned long len);
unsigned char SM3Final(unsigned char *dst);
unsigned char Sm3(const unsigned char *in,unsigned long len,unsigned char *dst);

#endif
