/****************************************************************\
* Copyright (C) 2005-2015 Beijing HuaDa InfoSec Tech. Co., Ltd
* All Rights Reserved
* File Name:		iscrypt_system.h
* Author:			         
* Version:			1.0.0.0        
* Date:				2014.04.16  
* Description:    
* 					1. Special Registers Definitions of the Chip
*					2. Some Macro Definitions about Operations 
*				   	   of Registers
*														  	
* Others:		
*					None
*         
* Function List:                
*   				1. 
*
* History:        
*                 
*   1. Date:
*      Author:
*      Modification:
*   2. ......
\****************************************************************/
#ifndef __IS_SYSTEM_H__
#define __IS_SYSTEM_H__

#define REG(x) (*((volatile unsigned long *)(x)))
#define PUL(x) ((unsigned long *)(x))

////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////
#define SYS_BASE		0x000F0000

////////////////////////////////////////////////////////////////

/* RNG */						
#define rRNGCON				REG(SYS_BASE + 0x2800)
#define rRNGSTR				REG(SYS_BASE + 0x2804)
#define rRNGOUT				REG(SYS_BASE + 0x2808)
#define rRNGIN				REG(SYS_BASE + 0x280C)
#define rRNGMODE			REG(SYS_BASE + 0x2810)

/* TRNG */
#define rTRNGTSTEN			REG(SYS_BASE + 0x2814)
#define rTRNGTSTCTR			REG(SYS_BASE + 0x2818)
#define rTRNGD				REG(SYS_BASE + 0x2820)


/* DES */
#define rDESCON				REG(SYS_BASE + 0x8000)
#define rDESDATA			REG(SYS_BASE + 0x8004)
#define rDESKEY				REG(SYS_BASE + 0x8008)


/* PKU Memory Map */
#define PKU_RAM0			PUL(SYS_BASE + 0x8800)
#define PKU_RAM1			PUL(SYS_BASE + 0x8820)
#define PKU_RAM2			PUL(SYS_BASE + 0x8840)
#define PKU_RAM3			PUL(SYS_BASE + 0x8860)
#define PKU_RAM4			PUL(SYS_BASE + 0x8880)
#define PKU_RAM5			PUL(SYS_BASE + 0x88A0)
#define PKU_RAM6			PUL(SYS_BASE + 0x88C0)
#define PKU_RAM7			PUL(SYS_BASE + 0x88E0)
#define PKU_RAM10			PUL(SYS_BASE + 0x8900)
#define PKU_RAM11			PUL(SYS_BASE + 0x8920)
#define PKU_RAM12			PUL(SYS_BASE + 0x8940)
#define PKU_RAM13			PUL(SYS_BASE + 0x8960)
#define PKU_RAM14			PUL(SYS_BASE + 0x8980)
#define PKU_RAM15			PUL(SYS_BASE + 0x89A0)
#define PKU_RAM16			PUL(SYS_BASE + 0x89C0)
#define PKU_RAM17			PUL(SYS_BASE + 0x89E0)
#define PKU_RAM20			PUL(SYS_BASE + 0x8A00)
#define PKU_RAM21			PUL(SYS_BASE + 0x8A20)
#define PKU_RAM22			PUL(SYS_BASE + 0x8A40)
#define PKU_RAM23			PUL(SYS_BASE + 0x8A60)
#define PKU_RAM24			PUL(SYS_BASE + 0x8A80)
#define PKU_RAM25			PUL(SYS_BASE + 0x8AA0)
#define PKU_RAM26			PUL(SYS_BASE + 0x8AC0)
#define PKU_RAM27			PUL(SYS_BASE + 0x8AE0)
#define PKU_RAM30			PUL(SYS_BASE + 0x8B00)
#define PKU_RAM31			PUL(SYS_BASE + 0x8B20)
#define PKU_RAM32			PUL(SYS_BASE + 0x8B40)
#define PKU_RAM33			PUL(SYS_BASE + 0x8B60)
#define PKU_RAM34			PUL(SYS_BASE + 0x8B80)
#define PKU_RAM35			PUL(SYS_BASE + 0x8BA0)
#define PKU_RAM36			PUL(SYS_BASE + 0x8BC0)
#define PKU_RAM37			PUL(SYS_BASE + 0x8BE0)


/* PKU Control Register */
#define	rPKUCMD				REG(SYS_BASE + 0x8C00)
#define	rPKUMCL				REG(SYS_BASE + 0x8C04)
#define rPKUMCH				REG(SYS_BASE + 0x8C08)
#define	rPKUSEGN			REG(SYS_BASE + 0x8C0C)
#define	rPKUEREG			REG(SYS_BASE + 0x8C10)
#define	rPKUINT				REG(SYS_BASE + 0x8C14)

/* SM1 */
#define rSM1CTRL			REG(SYS_BASE + 0x9800)
#define rSM1CFG				REG(SYS_BASE + 0x9804)
#define rSM1SK				REG(SYS_BASE + 0x9808)
#define rSM1MK				REG(SYS_BASE + 0x980C)
#define rSM1IV				REG(SYS_BASE + 0x9810)
#define rSM1DATA			REG(SYS_BASE + 0x9814)

/* AES */
#define rAESCON				REG(SYS_BASE + 0xA800)
#define rAESKEY				REG(SYS_BASE + 0xA804)
#define rAESIV				REG(SYS_BASE + 0xA808)
#define rAESDATA			REG(SYS_BASE + 0xA80C)

/* SM4 */
#define rSM4CON				REG(SYS_BASE + 0xB800)
#define rSM4DATA			REG(SYS_BASE + 0xB804)
#define rSM4KEY				REG(SYS_BASE + 0xB808)
#define rSM4IV				REG(SYS_BASE + 0xB80C)

/* SM7 */
#define rSM7CON				REG(SYS_BASE + 0xC000)
#define rSM7DATA			REG(SYS_BASE + 0xC004)
#define rSM7KEY				REG(SYS_BASE + 0xC008)
#define rSM7IV				REG(SYS_BASE + 0xC00C)

/* HASH */
#define rHASHCON			REG(SYS_BASE + 0xC800)
#define rHASHDATA			REG(SYS_BASE + 0xC804)


/* DMA */
#define rDMADCH0_TCR		REG(SYS_BASE + 0xE800)
#define rDMADCH0_FCR		REG(SYS_BASE + 0xE804)
#define rDMADCH0_SAR		REG(SYS_BASE + 0xE808)
#define rDMADCH0_DAR		REG(SYS_BASE + 0xE80C)
#define rDMADCH0_LER		REG(SYS_BASE + 0xE810)
#define rDMADCH0_STR		REG(SYS_BASE + 0xE814)

/* System Controller */
#define rSYSCLKEN			REG(SYS_BASE + 0xF200)
#define rSYSCLKCLR			REG(SYS_BASE + 0xF204)
#define rSYSCLKCFG			REG(SYS_BASE + 0xF208)

#define rSYSCLKPLLEN		REG(SYS_BASE + 0xF210)
#define rSYSCLKPLLCFG		REG(SYS_BASE + 0xF214)

#define rSYSCLKFWCCFG		REG(SYS_BASE + 0xF220)

#define rSYSPRAMREUSE		REG(SYS_BASE + 0xF42C)


#define rADCTL				REG(SYS_BASE + 0xF41C)
#define rCHIPCFG			REG(SYS_BASE + 0xF420)


////////////////////////////////////////////////////////////////

/* PKU Operations Mode */
#define PKU_HALT			0x00000000
#define PKU_MOD_MUL			0x01000000
#define PKU_MOD_ADD			0x02000000
#define PKU_MOD_SUB			0x04000000
#define PKU_ADD_JA			0x08000000
#define PKU_DBL_JJ			0x10000000
#define PKU_MOD_EXP			0x20000000


/* The tag of rSYSCLKEN and rSYSCLKCLR */
#define TRNG1CLKEN		(1 << 29)
#define TRNG0CLKEN		(1 << 28)
#define TRNG3CLKEN		(1 << 27)
#define TRNG2CLKEN		(1 << 26)


#define DMAEN			(1 << 11)

#define DRNGEN			(1 << 8)
#define HASHEN			(1 << 7)
#define SM7EN			(1 << 6)
#define AESEN			(1 << 5)
#define PKUEN			(1 << 4)
#define SM4EN			(1 << 3)
#define SM1EN			(1 << 2)
#define DESEN			(1 << 1)
#define CRCEN			(1)


/* The tag of rADCTL */
#define TRNG1SEL		(1 << 6)
#define TRNG1EN			(1 << 5)
#define TRNG0EN			(1 << 4)


/* The tag of rCHIPCFG */
#define AESCFG			(1 << 12)

#define SM1CFG			(1 << 10)

#define PKUCFG			(1 << 8)


////////////////////////////////////////////////////////////////

/*  */
#define WriteOpCmd(Cmd) (rPKUCMD = (Cmd))

#define CheckPKUDone()			\
{								\
	 while (!(rPKUCMD & 1));	\
}

#define WriteMC(MC)				\
{								\
	rPKUMCL = (unsigned long)MC;			\
	rPKUMCH = (unsigned long)(MC >> 32);	\
}

#define WriteReg(Exponent)	(rPKUEREG = (Exponent))
#define WriteSegN(n)		(rPKUSEGN = (n))


#endif
