/***************************************************\
*			
*			 All Right Reserved
*
*�ļ����ƣ�is32u64a_apdu.c
*��    �ߣ�
*��    ����
*��    �ڣ�2018.10.17
*�������������is32u64a��APDUָ���
*�����б���
*			1��
*			2��
*			3��
*��ʷ��¼��
*	1�� ���ڣ�
*		�汾��
*		���ߣ�
*	�޸����ݣ�
*	2��.....
\***************************************************/
#define __APDU_GLOBAL
#include <string.h>
#include "is32u64a.h"
#include "is32u64a_typesmacro.h"
#include "is32u64a_apdu.h"
#include "is32u64a_flash.h"
#include "is32u64a_timer.h"
#include "is32u64a_lowpower.h"
#include "iscrypt.h"
#include "iscrypt_aes.h"
#include "iscrypt_des.h"
#include "iscrypt_random.h"
#include "iscrypt_rsa.h"
#include "iscrypt_sha1.h"
#include "iscrypt_sha256.h"
#include "iscrypt_sm2.h"
#include "iscrypt_sm3.h"
#include "iscrypt_sm4.h"
#include "iscrypt_factory.h"
#include "iscrypt_symmetric.h"

#include "is32u64a_gpio.h"
/***************************************************\
*�������ƣ�ApduDeal
*�������ܣ�����apduָ��
*���������apduָ���ַpApduBuff
*�����������
*�� �� ֵ����
*����˵����
\***************************************************/


UINT32 ApduDeal(UINT8 *pApduBuff)
{
	BLOCKCIPHERPARAM BlockCipherParam;
	UINT32 total_len=0x0;
	UINT32 len,i,j;
	UINT32 addresstmp;
	UINT32 datatmp;
	UINT32 blocknum;
	UINT32 aeskeysize;
	static unsigned short SM2len;
	unsigned char tmpArray[128];
	UINT32 tmpreg=0x0;
	unsigned char SelfID[] = 
	{
		// SELF ID
		0X31,0X32,0X33,0X34,0X35,0X36,0X37,0X38,0X31,0X32,0X33,0X34,0X35,0X36,0X37,0X38
	};
	if(0xBF==CLA)
	{
		switch(INS)
		{
			case 0x00:								  //ReDownload
			{
				if((0x55==P1)&&(0xAA==P2))
				{
					if(0x00==P3)
					{
						ReDownload();
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;		
				}				
			}
			break;
			case 0x08:
			{
				if((0x00==P1)&&(0x00==P2))				//����Timer1
				{
					if(0x00==P3)
					{
						TimerOn(Timer1);
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x00==P1)&&(0x01==P2))			//�ر�Timer1
				{
					if(0x00==P3)
					{
						TimerOff(Timer1);
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}

				
			}
			break; 
			case 0x09:								  //Flash������8λ��ַ
			{
				if(0x00==P2)
				{
					if(0x00==P3)
					{
						g_Address = P1;
						g_Address <<= 16;
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02; 	
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
				
			}
			break;
			case 0x0a:
			*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02; 	
			break;		
			case 0x0B:								  //Flashд������Data
			{
				
				addresstmp = P1;
				addresstmp = (addresstmp<<8) + P2;
				addresstmp += (g_Address);
				
					
				/*д������ǰ�Ȳ���ǰ��Ҫд��ҳ��*/
				FlashNPageErase(addresstmp,1);
				memcpy(tmpArray,pApduBuff+5,P3);
				if(FlashWrite8(addresstmp,tmpArray,P3))
				{
					*(pApduBuff+0) = 0x68;
					*(pApduBuff+1) = 0x00;
				}
				else
				{
					*(pApduBuff+0) = 0x90;
					*(pApduBuff+1) = 0x00;
				}
				
				total_len = 0x02;
				
			}
			break;
			case 0x0C:								  //Flash��������Data
			{
				
				len = P3;
				addresstmp = P1;
				addresstmp = (addresstmp<<8) + P2;
				addresstmp += (g_Address);
				if(FlashRead8(pApduBuff,addresstmp,P3))
				{
					*(pApduBuff) = 0x68;
					*(pApduBuff+1) = 0x00;
					len=0;
				}
				else
				{
					*(pApduBuff+len) = 0x90;
					*(pApduBuff+len+1) = 0x00;
				}
					
				total_len = 0x02+len;
				
			}
			break;

			case 0x15:								  //CRCУ��
			{
				
				if((0x00==P1)&&(0x00==P2))					//CRCУ��ĳ�ʼֵ
				{
					
					if(0x02==P3)
					{
						
						datatmp = *(pApduBuff+5);
						datatmp = (datatmp<<8) + (*(pApduBuff+6));
						CRCIVData(datatmp);
						CRCOn();
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x01==P1)&&(0x00==P2))
				{
					
					if(0x00!=P3)
					{
						for(i=0;i<P3;i++)
						{
							CRCLoadData(*(pApduBuff+5+i));
						}
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;	
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x02==P1)&&(0x00==P2))
				{
					if(0x02==P3)
					{
						datatmp = CRCResult();
						*(pApduBuff+0) = (datatmp>>8)&0xFF;
						*(pApduBuff+1) = datatmp&0xFF;
						*(pApduBuff+2) = 0x90;
						*(pApduBuff+3) = 0x00;
						total_len = 0x04;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x16:								  //����͹��ģ�����
			{
			
				*(pApduBuff+0) = 0x90;
				*(pApduBuff+1) = 0x00;
				total_len = 0x02;
				if(P1==0)
				{
				LowPowerOn_7816();
				}
				else if(P1==0x01)
				{
				LowPowerOn_Non7816();
				}
				SySClkInit();	
			}
			break; 
			case 0x17:								  //����/�رտ��Ź�
			{
				if((0x00==P1)&&(0x00==P2))			  	//�������Ź�
				{
					if(0x00==P3)
					{
						WatchDogOn();
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x01==P1)&&(0x00==P2))         //�رտ��Ź�
				{
					if(0x00==P3)
					{
						WatchDogOff();
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x67;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x18:
			{
				switch (P1)
				{
					case 0: 
					  u32WRITE(SYSCLKFWCCFG,0x11);
						SetRegVal(SYSCLKCFG,4,2,0);	//ʱ�Ӳ���Ƶ
          
						break;
				  case 1:
						u32WRITE(SYSCLKFWCCFG,0x0);
						SetRegVal(SYSCLKCFG,4,2,1);//ʱ��2��Ƶ
				    break;
					case 2: 
						u32WRITE(SYSCLKFWCCFG,0x0);
						SetRegVal(SYSCLKCFG,4,2,2);//ʱ��4��Ƶ
					 
				    break;
				  case 3:
						u32WRITE(SYSCLKFWCCFG,0x0);
						SetRegVal(SYSCLKCFG,4,2,3);  //ʱ��8��Ƶ
					  
					  break;
					default:
						u32WRITE(SYSCLKFWCCFG,0x0);
						SetRegVal(SYSCLKCFG,4,2,1);//����ֵΪ2��Ƶ
				    break;
				    
				}
			
				*(pApduBuff+0) = 0x90;
				*(pApduBuff+1) = 0x00;
				total_len = 0x02;
			}
				break;
			case 0x20:								
			{
#ifdef			USE_PMU_BUFFER

#else				
				len = P3%8;
				if(0x00==len)
				{	
					blocknum = P3/DES_BLOCK_SIZE;
					BlockCipherParam.pbKey = keybuffer;
					BlockCipherParam.pbIV = NULL;
					BlockCipherParam.pbInput = pApduBuff + 5;
					BlockCipherParam.TotalBlock = blocknum;
					BlockCipherParam.pbOutput = buffer;
					if((0x00==P1)&&(0x00==P2))					//DES_ECB����
					{
							BlockCipherParam.OpMode = SYM_ECB | SYM_ENCRYPT;
							if (SUCCESS != DESCrypt(&BlockCipherParam))
							{
								
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}
							else
							{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}

					}
					else if((0x00==P1)&&(0x01==P2))				//DES_ECB����
					{
						BlockCipherParam.OpMode = SYM_ECB | SYM_DECRYPT;
						if (SUCCESS != DESCrypt(&BlockCipherParam))
						{
							
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}

					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
#endif				
			}
			break;
			case 0x21:
			{
				len = P3%8;
				if(0x00==len)
				{
						blocknum = P3/DES_BLOCK_SIZE;
						BlockCipherParam.pbIV = keybuffer+8;
						BlockCipherParam.pbKey = keybuffer;
						BlockCipherParam.TotalBlock = blocknum;
						BlockCipherParam.pbInput = pApduBuff + 5;
						BlockCipherParam.pbOutput = buffer;
						if((0x00==P1)&&(0x00==P2))					//DES_CBC����
						{
								BlockCipherParam.OpMode = SYM_CBC | SYM_ENCRYPT;
								if (SUCCESS != DESCrypt(&BlockCipherParam))
								{
									
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}
								else
								{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}																									
						}
						else if((0x00==P1)&&(0x01==P2))				//DES_CBC����
						{
									BlockCipherParam.OpMode = SYM_CBC | SYM_DECRYPT;
									if (SUCCESS != DESCrypt(&BlockCipherParam))
									{
										
										*(pApduBuff+0) = 0x68;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									}
									else
									{
										*(pApduBuff+0) = 0x90;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									}									
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}				
			}
			break;
			case 0x22:
			{				
				len = P3%8;
				if(0x00==len)
				{
						blocknum = P3/TDES_BLOCK_SIZE;
						BlockCipherParam.pbIV = NULL;
						BlockCipherParam.pbKey = keybuffer;
						BlockCipherParam.TotalBlock = blocknum;
						BlockCipherParam.pbInput = pApduBuff+5;
						BlockCipherParam.pbOutput = buffer;
						if((0x00==P1)&&(0x00==P2))					//TDES_ECB����
						{														
								BlockCipherParam.OpMode = SYM_ECB | SYM_ENCRYPT|SYM_EDE2 ;
								if(SUCCESS!=TDESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
								{	
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}
								else
								{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}							
						}
						else if((0x00==P1)&&(0x01==P2))				//TDES_ECB����
						{
									BlockCipherParam.OpMode = SYM_ECB | SYM_DECRYPT|SYM_EDE2 ;
									if(SUCCESS!=TDESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
									{	
										*(pApduBuff+0) = 0x68;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									}
									else
									{
										*(pApduBuff+0) = 0x90;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									}						
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}				
			}
			break;
			case 0x23:
			{				
				len = P3%8;
				if(0x00==len)
				{
						blocknum = P3/TDES_BLOCK_SIZE;
						BlockCipherParam.pbIV = keybuffer+16;
						BlockCipherParam.pbKey = keybuffer;
						BlockCipherParam.TotalBlock = blocknum;
						BlockCipherParam.pbInput = pApduBuff+5;
						BlockCipherParam.pbOutput = buffer;
						if((0x00==P1)&&(0x00==P2))					//TDES_CBC����
						{																	
								BlockCipherParam.OpMode = SYM_CBC | SYM_ENCRYPT|SYM_EDE2 ;
								if(SUCCESS!=TDESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
								{	
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}
								else
								{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}					
						}
						else if((0x00==P1)&&(0x01==P2))				//TDES_CBC����
						{
									BlockCipherParam.OpMode = SYM_CBC | SYM_DECRYPT|SYM_EDE2 ;
									if(SUCCESS!=TDESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
									{	
										*(pApduBuff+0) = 0x68;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									}
									else
									{
										*(pApduBuff+0) = 0x90;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									}					
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}				
			}
			break;
			case 0x26:
			{
				
				len = P3%8;
				if(0x00==len)
				{
					BlockCipherParam.pbIV = NULL;
					BlockCipherParam.pbKey = keybuffer;
					BlockCipherParam.pbOutput = buffer;
					if((0x00==P1)&&(0x00==P2))					//AES128_ECB����
					{
								//aeskeysize = 128/8;
							blocknum = P3/AES_BLOCK_SIZE;
							BlockCipherParam.OpMode = SYM_ECB | SYM_ENCRYPT | SYM_AES128;
							BlockCipherParam.TotalBlock = blocknum;
							BlockCipherParam.pbInput = pApduBuff + 5 ;
							if(SUCCESS!=AESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
							{
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}
							else
							{	
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}		
					}
					else if((0x00==P1)&&(0x01==P2))				//AES128_ECB����
					{
								blocknum = P3/AES_BLOCK_SIZE;
								BlockCipherParam.OpMode = SYM_ECB | SYM_DECRYPT | SYM_AES128;
								BlockCipherParam.TotalBlock = blocknum;
								BlockCipherParam.pbInput = pApduBuff + 5 ;
								if(SUCCESS!=AESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
								{
										*(pApduBuff+0) = 0x68;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
								}
								else
								{	
										*(pApduBuff+0) = 0x90;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
								}

					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x27:
			{				
				len = P3%8;
				if(0x00==len)
				{
						BlockCipherParam.pbKey = keybuffer;
						BlockCipherParam.pbOutput = buffer;
						if((0x00==P1)&&(0x00==P2))					//AES128_CBC����
						{
									aeskeysize = 128/8;
									blocknum = P3/AES_BLOCK_SIZE;
									BlockCipherParam.OpMode = SYM_CBC | SYM_ENCRYPT | SYM_AES128;
									BlockCipherParam.pbIV = keybuffer + aeskeysize;
									BlockCipherParam.TotalBlock = blocknum;
									BlockCipherParam.pbInput = pApduBuff + 5 ;
									if(SUCCESS!=AESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
									{
										*(pApduBuff+0) = 0x68;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									}
									else
									{	
											*(pApduBuff+0) = 0x90;
											*(pApduBuff+1) = 0x00;
											total_len = 0x02;
									}
						}
						else if((0x00==P1)&&(0x01==P2))				//AES128_CBC����
						{			
							aeskeysize = 128/8;
							blocknum = P3/AES_BLOCK_SIZE;
							BlockCipherParam.OpMode = SYM_CBC | SYM_DECRYPT | SYM_AES128;
							BlockCipherParam.pbIV = keybuffer + aeskeysize;
							BlockCipherParam.TotalBlock = blocknum;
							BlockCipherParam.pbInput = pApduBuff + 5;
							if(SUCCESS!=AESCrypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
							{
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
							else
							{	
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
						}					
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
			}
			break;
			case 0x28:
			{
				if(0x00==P3)
				{
					if((0x00==P1)&&(0x00==P2))				//SHA1 ��ʼ��
					{
						if(SUCCESS!=SHA1Init())
						{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
					}
				
					else if((0x00==P1)&&(0x02==P2))			//SHA256 ��ʼ��
					{
						if(0!=SHA256Init())
						{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
					}
					else if((0x00==P1)&&(0x05==P2))			//SM3 ��ʼ��
					{
						if(SUCCESS!=SM3Init())
						{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x67;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x29:
			{
				
				if((0x00==P1)&&(0x00==P2))				//SHA1 Update
				{
						
						if(SUCCESS!=SHA1Update((const unsigned char *)pApduBuff+5,P3))
						{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
				}
			
				else if((0x00==P1)&&(0x02==P2))			//SHA256 Update
				{
						if(SUCCESS!=SHA256Update((const unsigned char *)pApduBuff+5,P3))
						{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
				}
				else if((0x00==P1)&&(0x05==P2))			//SM3 Update
				{
					
						if(SUCCESS!=SM3Update((const unsigned char *)pApduBuff+5,P3))
						{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x2A:
			{				
				if((0x00==P1)&&(0x00==P2))				//SHA1 Final
				{		
							if(SUCCESS!=SHA1Final(buffer))
							{
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}
							else
							{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
				}			
				else if((0x00==P1)&&(0x02==P2))			//SHA256 Final
				{					
						if(SUCCESS!=SHA256Final(buffer))
						{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}						
				}
				else if((0x00==P1)&&(0x05==P2))			//SM3 Final
				{									
								
							if(SUCCESS!=SM3Final(buffer))
							{
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}
							else
							{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x2B:									//��ȡ�Գơ�SM3��HASH��������
			{
				if((0x00==P1)&&(0x00==P2))
				{	
					len = P3;
					memcpy(pApduBuff+0,buffer,P3);
					*(pApduBuff+len) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x2C:	
			{				
				if((0x00==P1)&&(0x00==P2))				//���빫Կe
				{
					if(0x04==P3)
					{
						memcpy(buffer+RSA_E_OFFSET,pApduBuff+5,P3);
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x00==P1)&&(0x01==P2))			//����N��ǰ128Byte
				{
					if(0x80==P3)
					{
						memcpy(buffer+RSA_N_OFFSET,pApduBuff+5,P3);	
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x00==P1)&&(0x02==P2))			//����N��ʣ��Byte,
				{
					memcpy(buffer+RSA_N_OFFSET+128,pApduBuff+5,P3);					
					*(pApduBuff+0) = 0x90;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				else if((0x01==P1)&&(0x00==P2))			//����D��ǰ128Byte
				{
						if(0x80==P3)
						{
							memcpy(buffer+RSA_D_OFFSET,pApduBuff+5,P3);					
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
				}
 				else if((0x01==P1)&&(0x01==P2))			//����D��ʣ��Byte
 				{
 					memcpy(buffer+RSA_D_OFFSET+128,pApduBuff+5,P3);					
 					*(pApduBuff+0) = 0x90;
 					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
 				}
 				else if((0x01==P1)&&(0x02==P2))			//����P
 				{
 					memcpy(buffer+RSA_P_OFFSET,pApduBuff+5,P3);					
 					*(pApduBuff+0) = 0x90;
 					*(pApduBuff+1) = 0x00;
 					total_len = 0x02;
 				}
 				else if((0x01==P1)&&(0x03==P2))			//����q
 				{
 					memcpy(buffer+RSA_Q_OFFSET,pApduBuff+5,P3);					
 					*(pApduBuff+0) = 0x90;
 					*(pApduBuff+1) = 0x00;
 					total_len = 0x02;
 				}
 				else if((0x01==P1)&&(0x04==P2))			//����dP
 				{
 					memcpy(buffer+RSA_DP_OFFSET,pApduBuff+5,P3);						
 					*(pApduBuff+0) = 0x90;
 					*(pApduBuff+1) = 0x00;
 					total_len = 0x02;
 				}
 				else if((0x01==P1)&&(0x05==P2))			//����dQ
 				{
 					memcpy(buffer+RSA_DQ_OFFSET,pApduBuff+5,P3);					
 					*(pApduBuff+0) = 0x90;
 					*(pApduBuff+1) = 0x00;
 					total_len = 0x02;
 				}
 				else if((0x01==P1)&&(0x06==P2))			//����qInv
 				{
 					memcpy(buffer+RSA_QINV_OFFSET,pApduBuff+5,P3);				
 					*(pApduBuff+0) = 0x90;
 					*(pApduBuff+1) = 0x00;
 					total_len = 0x02;
 				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}				
			}
			break;
			case 0x2D:
			{				
				len = P3;
				if((0x00==P1)&&(0x00==P2))				//������Կe
				{
					if(0x04==P3)
					{
						memcpy(pApduBuff,buffer+RSA_E_OFFSET,P3);							
						*(pApduBuff+len+0) = 0x90;
						*(pApduBuff+len+1) = 0x00;
						total_len = len+0x02; 
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x00==P1)&&(0x01==P2))			//����N��ǰ128Byte
				{
					if(0x80==P3)
					{
						memcpy(pApduBuff,buffer+RSA_N_OFFSET,P3);						
						*(pApduBuff+len+0) = 0x90;
						*(pApduBuff+len+1) = 0x00;
						total_len = len+0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x00==P1)&&(0x02==P2))			//����N��ʣ��Byte,
				{
					memcpy(pApduBuff,buffer+RSA_N_OFFSET+128,P3);					
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else if((0x01==P1)&&(0x00==P2))			//����D��ǰ128Byte
				{
					if(0x80==P3)
					{
						memcpy(pApduBuff,buffer+RSA_D_OFFSET,P3);						
					*(pApduBuff+len+0) = 0x90;
						*(pApduBuff+len+1) = 0x00;
						total_len = len+0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x01==P1)&&(0x01==P2))			//����D��ʣ��Byte
				{
					memcpy(pApduBuff,buffer+RSA_D_OFFSET+128,P3);					
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else if((0x01==P1)&&(0x02==P2))			//����P
				{
					memcpy(pApduBuff,buffer+RSA_P_OFFSET,P3);					
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else if((0x01==P1)&&(0x03==P2))			//����q
				{
					memcpy(pApduBuff,buffer+RSA_Q_OFFSET,P3);					
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else if((0x01==P1)&&(0x04==P2))			//����dP
				{
					memcpy(pApduBuff,buffer+RSA_DP_OFFSET,P3);					
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else if((0x01==P1)&&(0x05==P2))			//����dQ
				{
					memcpy(pApduBuff,buffer+RSA_DQ_OFFSET,P3);					
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else if((0x01==P1)&&(0x06==P2))			//����qInv
				{
					memcpy(pApduBuff,buffer+RSA_QINV_OFFSET,P3);				
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break; 			
			case 0x2E:
			{				
				if((0x00==P1)&&(0x00==P2))
				{
					if(0x02==P3)
					{
						bitlen = *(pApduBuff+5);
						bitlen = (bitlen<<8) + *(pApduBuff+6);				
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x30:							
			{				
				if(0x00==P1)					//RSA����
				{
					if(0x00==P2)
					{
						if(0x80==P3)
						{
							memcpy(buffer+RSA_DATA_OFFSET,pApduBuff+5,P3);							
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
					}
					else if(0x01==P2)
					{
						memcpy(buffer+RSA_DATA_OFFSET+128,pApduBuff+5,P3);
						RSAPubKeyCTX.e = buffer+RSA_E_OFFSET;
						RSAPubKeyCTX.n = buffer+RSA_N_OFFSET;
						if(SUCCESS!=RSAEncrypt(bitlen,&RSAPubKeyCTX,buffer+RSA_DATA_OFFSET))
						{	
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}					
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if(0x01==P1)				//RSA����
				{
					if(0x00==P2)					
					{
						if(0x80==P3)
						{
							memcpy(buffer+RSA_DATA_OFFSET,pApduBuff+5,P3);							
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
					}
					else if(0x02==P2)				//CRT-Mode
					{
							memcpy(buffer+RSA_DATA_OFFSET+128,pApduBuff+5,P3);
							RSAPriKeyCRT.p = buffer+RSA_P_OFFSET;
							RSAPriKeyCRT.q = buffer+RSA_Q_OFFSET;
							RSAPriKeyCRT.dP = buffer+RSA_DP_OFFSET;
							RSAPriKeyCRT.dQ = buffer+RSA_DQ_OFFSET;
							RSAPriKeyCRT.qInv = buffer+RSA_QINV_OFFSET;
							RSAPriKeyCRT.n = buffer+RSA_N_OFFSET;
							if(SUCCESS!=RSADecrypt(bitlen,&RSAPriKeyCRT,buffer+RSA_DATA_OFFSET))
							{	
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
							else
							{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}					
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}				
			}
			break;
			case 0x31:
			{				
				if(0x00==P1)								//RSAǩ��
				{
					if(0x00==P2)								//��ǩ����ϢժҪǰ128Byte
					{
						if(0x80==P3)
						{
							memcpy(buffer+RSA_DATA_OFFSET,pApduBuff+5,P3);							
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
					}
					else if(0x02==P2)							//��ǩ����ϢժҪʣ��Byte,CRTģʽǩ��
					{
						
							memcpy(buffer+RSA_DATA_OFFSET+128,pApduBuff+5,P3);
							RSAPriKeyCRT.p = buffer+RSA_P_OFFSET;
							RSAPriKeyCRT.q = buffer+RSA_Q_OFFSET;
							RSAPriKeyCRT.dP = buffer+RSA_DP_OFFSET;
							RSAPriKeyCRT.dQ = buffer+RSA_DQ_OFFSET;
							RSAPriKeyCRT.qInv = buffer+RSA_QINV_OFFSET;
							RSAPriKeyCRT.n = buffer+RSA_N_OFFSET;
							if(SUCCESS!=RSASign(bitlen,&RSAPriKeyCRT,buffer+RSA_DATA_OFFSET))
							{	
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
							else
							{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}				
							

					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if(0x01==P1)							//RSA��֤
				{
					if(0x00==P2)								//��ϢժҪ��ǰ128Byte
					{
						if(0x80==P3)
						{
							memcpy(buffer+RSA_DATA_OFFSET,pApduBuff+5,P3);							
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
					}
					else if(0x01==P2)							//��ϢժҪʣ��Byte
					{
						memcpy(buffer+RSA_DATA_OFFSET+128,pApduBuff+5,P3);						
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else if(0x02==P2)							//ǩ��ֵ��ǰ128Byte
					{
						if(0x80==P3)
						{
							memcpy(buffer+RSA_DATA_OFFSET+256,pApduBuff+5,P3);							
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
						}
						else
						{
							*(pApduBuff+0) = 0x67;
							*(pApduBuff+1) = 0x00;
						total_len = 0x02;
						}
					}
					else if(0x03==P2)							//ǩ��ֵ��ʣ��Byte������֤
					{
							memcpy(buffer+RSA_DATA_OFFSET+256+128,pApduBuff+5,P3);
							RSAPubKeyCTX.e = buffer+RSA_E_OFFSET;
							RSAPubKeyCTX.n = buffer+RSA_N_OFFSET;
							if(SUCCESS!=RSAVerify(bitlen,&RSAPubKeyCTX,buffer+RSA_DATA_OFFSET+256,buffer+RSA_DATA_OFFSET))
							{	
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
							else
							{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}					
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x32:
			{							
				if((0x00==P1)&&(0x00==P2))
				{
					if(0x80==P3)
					{
						len = P3;					
						memcpy(pApduBuff,buffer+RSA_DATA_OFFSET,P3);						
						*(pApduBuff+len+0) = 0x90;
						*(pApduBuff+len+1) = 0x00;
						total_len = len+0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if((0x00==P1)&&(0x01==P2))
				{
					len = P3;					
					memcpy(pApduBuff,buffer+RSA_DATA_OFFSET+128,P3);					
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = len+0x02;
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
			}
			break; 
			case 0x33:
			{				
				if(0x00==P1)					
				{
					
					if(0x00==P2)					//���빫ԿGX+GY
					{						
						memcpy(buffer+SM2_GX_OFFSET,pApduBuff+5,P3);
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else if(0x01==P2)				//����˽ԿD
					{
						memcpy(buffer+SM2_D_OFFSET,pApduBuff+5,P3);
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else if(0x01==P1)
				{
					len = P3;
					if(0x00==P2)					//������ԿGX+GY
					{
						memcpy(pApduBuff,buffer+SM2_GX_OFFSET,P3);
						*(pApduBuff+len+0) = 0x90;
						*(pApduBuff+len+1) = 0x00;
						total_len = 0x02+len;
					}
					else if(0x01==P2)				//����˽ԿD
					{
						memcpy(pApduBuff,buffer+SM2_D_OFFSET,P3);
						*(pApduBuff+len+0) = 0x90;
						*(pApduBuff+len+1) = 0x00;
						total_len = 0x02+len;
					}
					else
					{
						*(pApduBuff+0) = 0x6B;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
			}
			break;
			case 0x34:								//SM2������Կ��
			{								
				if((0x00==P1)&&(0x00==P2))
				{
					if(0x00==P3)
					{
							SM2PubKeyCTX.xy = buffer+SM2_GX_OFFSET;
							SM2PriKeyCTX.d = buffer+SM2_D_OFFSET;
							if(SUCCESS!=SM2GenKeyPair(&SM2PubKeyCTX,&SM2PriKeyCTX,0x00))
							{
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
							else
							{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
							}
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}	
			}
			break;
			case 0x35:
			{				
				if(0x00==P1)						//SM2��������
				{
					SM2len = P3;
					memcpy(buffer+SM2_PLAIN_OFFSET+P2,pApduBuff+5,P3);
					*(pApduBuff+0) = 0x90;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				else if(0x01==P1)					//SM2��������
				{
					if(P2 == 0x00)
					{						
						memcpy(buffer+SM2_CIPHER_X_OFFSET,pApduBuff+5,65);			//����C1
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else if(P2 == 0x40)
					{						
						memcpy(buffer+SM2_CIPHER_HASH_OFFSET,pApduBuff+5,32);		 //����C3
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else if(P2 == 0x60)
					{
						SM2len = P3;											   //ʵ�����ĳ���
						memcpy(buffer+SM2_CIPHER_CIPHER_OFFSET+97,pApduBuff+5,P3);		  //����C2
						*(pApduBuff+0) = 0x90;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
					else
					{
						*(pApduBuff+0) = 0x6b;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}					
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break; 
			case 0x36:
			{
				

					SM2CipherText1.c = buffer+SM2_CIPHER_CIPHER_OFFSET;
					SM2PlainText1.pd = buffer+SM2_PLAIN_OFFSET;
					SM2PlainText1.len = SM2len;
				
					
					if(0x00==P3)
					{
								if((0x00==P1)&&(0x00==P2))				//SM2����
								{
										SM2PubKeyCTX.xy = buffer+SM2_GX_OFFSET;
										if(SUCCESS!=SM2Encrypt(&SM2PubKeyCTX,&SM2PlainText1,&SM2CipherText1))
										{
												*(pApduBuff+0) = 0x68;
												*(pApduBuff+1) = 0x00;
												total_len = 0x02;
										}
										else
										{
												*(pApduBuff+0) = 0x90;
												*(pApduBuff+1) = 0x00;
												total_len = 0x02;
										}
								}
								else if((0x00==P1)&&(0x01==P2))			//SM2����
								{
										SM2PriKeyCTX.d = buffer+SM2_D_OFFSET;
										SM2CipherText1.len = SM2len;	//ʵ�����ĳ���
						
										if(SUCCESS!=SM2Decrypt(&SM2PriKeyCTX,&SM2CipherText1,&SM2PlainText1))
										{
												*(pApduBuff+0) = 0x68;
												*(pApduBuff+1) = 0x00;
												total_len = 0x02;
										}
										else
										{
												*(pApduBuff+0) = 0x90;
												*(pApduBuff+1) = 0x00;
												total_len = 0x02;
										}
								}
								else
								{
									*(pApduBuff+0) = 0x6B;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}
					}
					else
					{
						*(pApduBuff+0) = 0x67;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				
			}
			break;
			case 0x37:
			{  				
				if(0x00==P1)					//��ȡSM2���ܽ��
				{
					len = P3;
									
					memcpy(pApduBuff,buffer+SM2_CIPHER_CIPHER_OFFSET+P2,P3);				
					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = 0x02+len;
				}
				else if(0x01==P1)				//��ȡSM2���ܽ��
				{
					len = P3;
					
					memcpy(pApduBuff,buffer+SM2_PLAIN_OFFSET+P2,P3);

					*(pApduBuff+len+0) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = 0x02+len;
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x38:						
			{				
				SM2Signature1.rs = buffer+SM2_SIGNATURE_R_OFFSET;
				if((0x00==P1)&&(0x00==P2))			//SM2ǩ��
				{
						SM2PriKeyCTX.d = buffer+SM2_D_OFFSET;
						memcpy(buffer+SM2_DIGEST_OFFSET,pApduBuff+5,32); 
						if(SUCCESS!=SM2Sign(&SM2PriKeyCTX,buffer+SM2_DIGEST_OFFSET,&SM2Signature1))
						{
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
						else
						{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
				}
				else if((0x00==P1)&&(0x01==P2))	    //SM2��֤
				{
						SM2PubKeyCTX.xy = buffer+SM2_GX_OFFSET;
						memcpy(buffer+SM2_DIGEST_OFFSET,pApduBuff+5,32);
						memcpy(buffer+SM2_SIGNATURE_R_OFFSET,pApduBuff+5+32,64);
						if(SUCCESS!=SM2Verify(&SM2PubKeyCTX,buffer+SM2_DIGEST_OFFSET,&SM2Signature1))
						{
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
						else
						{								
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;				
						}	
				}
				else if((0x00==P1)&&(0x02==P2))		//��Ԥ������
				{
						SM2PubKeyCTX.xy = buffer+SM2_GX_OFFSET;
						SM2PriKeyCTX.d = buffer+SM2_D_OFFSET;
						if(SUCCESS!=SM2PreSign(&SM2PriKeyCTX,&SM2PubKeyCTX,SelfID,0x10,(unsigned char *)pApduBuff+5,P3,&SM2Signature1))
						{
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
						else
						{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
						}
				}
				else if((0x00==P1)&&(0x03==P2))
				{
					SM2PubKeyCTX.xy = buffer+SM2_GX_OFFSET;						
					memcpy(buffer+SM2_SIGNATURE_R_OFFSET,pApduBuff+5+P3-64,64);
					if(SUCCESS!=SM2PreVerify(&SM2PubKeyCTX,SelfID,0x10,(unsigned char *)pApduBuff+5,P3-64,&SM2Signature1))
					{
							*(pApduBuff+0) = 0x68;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
					}
					else
					{
							*(pApduBuff+0) = 0x90;
							*(pApduBuff+1) = 0x00;
							total_len = 0x02;
					}	
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
			}
			break;
			case 0x39:
			{			
				if((0x00==P1)&&(0x00==P2))
				{
					
					memcpy(pApduBuff,buffer+SM2_SIGNATURE_R_OFFSET,64);
					*(pApduBuff+0x40) = 0x90;
					*(pApduBuff+0x41) = 0x00;
					total_len = 0x02+0x40;
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			case 0x3c:	   							//�������
			{
				len = P3;
				if((0x00==P1)&&(0x00==P2))
				{
						GenRandom(len,pApduBuff);
						*(pApduBuff+len) = 0x90;
						*(pApduBuff+len+1) = 0x00;
						total_len = 0x02+len;
				
				}
				else
				{
					*(pApduBuff+0) = 0x6B;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
			
			}
			break; 			
			case 0x3D:								  //��������
			{	
				len = P3;
				if(P3==0x10)
				{
					GetFactoryCode(pApduBuff);		
					*(pApduBuff+len) = 0x90;
					*(pApduBuff+len+1) = 0x00;
					total_len = 0x02+len;
					
				}
				else
				{
					*(pApduBuff+0) = 0x67;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
			}
			break;
			case 0x3E:
			{	
				len = P3%8;
				if(0x00==len)
				{
						blocknum = P3/SM4_BLOCK_SIZE;					
						BlockCipherParam.TotalBlock = blocknum;
						BlockCipherParam.pbInput = pApduBuff + 5 ;
						BlockCipherParam.pbOutput = buffer;
						if((0x00==P1)&&(0x00==P2))					//SM4_ECB����
						{
							BlockCipherParam.OpMode = SYM_ECB | SYM_ENCRYPT;
							BlockCipherParam.pbIV = NULL;
							BlockCipherParam.pbKey = keybuffer;
							if(SUCCESS != SM4Crypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
							{
								*(pApduBuff+0) = 0x68;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}
							else
							{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}
						}
						else if((0x00==P1)&&(0x01==P2))				//SM4_ECB����
						{
								BlockCipherParam.OpMode = SYM_ECB | SYM_DECRYPT;
								BlockCipherParam.pbIV = NULL;
								BlockCipherParam.pbKey = keybuffer;
								if(SUCCESS!=SM4Crypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
								{
										*(pApduBuff+0) = 0x68;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									
								}
								else
								{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}
						}
					else if((0x01==P1)&&(0x00==P2))					//SM4_CBC����
					{				
							BlockCipherParam.OpMode = SYM_CBC | SYM_ENCRYPT;
							BlockCipherParam.pbIV = keybuffer+16;
							BlockCipherParam.pbKey = keybuffer;
							if(SUCCESS != SM4Crypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
							{
									*(pApduBuff+0) = 0x68;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								
							}
							else
							{
								*(pApduBuff+0) = 0x90;
								*(pApduBuff+1) = 0x00;
								total_len = 0x02;
							}
					}
					else if((0x01==P1)&&(0x01==P2))				//SM4_CBC����
					{			
								BlockCipherParam.OpMode = SYM_CBC | SYM_DECRYPT;
								BlockCipherParam.pbIV = keybuffer+16;
								BlockCipherParam.pbKey = keybuffer;
								if(SUCCESS!=SM4Crypt((BLOCKCIPHERPARAM *)&BlockCipherParam))
								{
										*(pApduBuff+0) = 0x68;
										*(pApduBuff+1) = 0x00;
										total_len = 0x02;
									
								}
								else
								{
									*(pApduBuff+0) = 0x90;
									*(pApduBuff+1) = 0x00;
									total_len = 0x02;
								}
					}
					else
					{
						*(pApduBuff+0) = 0x6b;
						*(pApduBuff+1) = 0x00;
						total_len = 0x02;
					}
				}
				else
				{
					*(pApduBuff+0) = 0x67;
					*(pApduBuff+1) = 0x00;
					total_len = 0x02;
				}
				
			}
			break;
			
			case 0x50:
					
				for(i=0;i<P3;i++)
				{
					keybuffer[i]=pApduBuff[5+i];
				}
				*(pApduBuff+0) = 0x90;
				*(pApduBuff+1) = 0x00;
				total_len = 0x02;
				
			break;
			
			
			default:
			{
  			*(pApduBuff+0)=0x6D;
				*(pApduBuff+1)=0x00;
				total_len = 0x02;
				
			}
			break;
		}
	}
	else
	{
		*(pApduBuff+0)=0x6E;
		*(pApduBuff+1)=0x00;
		total_len = 0x02;
		
	}
	// security: polarity(����)	
	/*				u32WRITE(CPUSAFECON, u32READ(CPUSAFECON)|0x08);  // enable polarity en
					
					// security: flush(�����ת)
					u32WRITE(CPUSAFECON, u32READ(CPUSAFECON)|0x0c);  // enable iflush en
					
					// security: clock gating(ʱ���ſ�)
					u32WRITE(CPUSAFECON, u32READ(CPUSAFECON)|0x0e);  // enable clk always on*/
	return total_len;
}

void U32ToU8(UINT32 *src,UINT8 *des,UINT8 bytelen)	   
{

	UINT8 i=0;
	UINT32 kk,jj,temp=0;
	kk = bytelen/4;
	jj = bytelen%4;
	for(i=0;i<kk;i++)
	{
		temp = *(src+i);
		*(des+i*4+0) = (temp>>24)&0xFF;
		*(des+i*4+1) = (temp>>16)&0xFF;
		*(des+i*4+2) = (temp>>8)&0xFF;
		*(des+i*4+3) = (temp>>0)&0xFF;
	}
	temp = *(src+kk); 

	for(i=0; jj; i++,jj--)
	{
		*(des+4*kk+i) = ( temp>>(24-8*i))&0xFF;
	}

}

void U8ToU32(UINT8 *src,UINT32 *des,UINT32 bytelen)
{
	UINT8 i=0;
	UINT32 wordlen=0;
	UINT32 temp=0;
	wordlen = ((bytelen%4)==0)?(bytelen/4):((bytelen/4)+1);
	for(i=0;i<wordlen;i++)
	{
		temp = (*(src+i*4+0));
		temp = (temp<<8) + (*(src+i*4+1));
		temp = (temp<<8) + (*(src+i*4+2));
		temp = (temp<<8) + (*(src+i*4+3));
		*(des+i) = temp;
		temp = 0;
	}
}
