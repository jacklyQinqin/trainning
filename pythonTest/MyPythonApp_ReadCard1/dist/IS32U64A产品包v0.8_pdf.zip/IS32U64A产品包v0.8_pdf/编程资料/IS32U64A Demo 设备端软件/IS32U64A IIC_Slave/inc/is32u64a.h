									         /*(c) Copyright 2008-2013��XA
                                                  All rights reserved */
//**************************************************************************
//*\�ļ����ƣ�XA1710.h
//*\ժҪ��    ����XA1710��ģ��Ĵ����ĵ�ַ
//*\��ǰ�汾��Ver1.0
//*\���ߣ�    hanym
//*\������ڣ�2017-12-5
//*\ȡ���汾��--
//*\ԭ���ߣ�  --
//*\������ڣ�--
//***************************************************************************


//�洢����ַ
#define ROM_ADDR		0x00000000
#define AROM_ADDR		0x00002000
#define FLS_ADD			0x00020000
#define DMEM_ADDR		0x000D0000
#define NVR_ADDR		0x0001F000

#define AHB_ADDR		0x000F8000
#define APB_ADDR		0x000F0000

// sysctrl
#define SYS_ADDR		0x000FF000

// new
// emmu
#define EMMUMP0			0x000FF00c
#define	EMMUMP1			0x000FF010
#define EMMUMP2			0x000FF014

// flash control
#define SYSNVMCTRL 		0x000FF080
#define PARA_TNVSP		0x000FF084
#define PARA_TNVSE		0x000FF088
#define PARA_TNVSEC		0x000FF08C
#define PARA_TPROG		0x000FF090
#define PARA_TPGS		0x000FF094
#define PARA_TRCVP		0x000FF098
#define PARA_TRCVE		0x000FF09C
#define PARA_TRCVEC		0x000FF0A0
#define PARA_TERASE		0x000FF0A4
#define PARA_TERASEC		0x000FF0A8
#define PARA_TRW		0x000FF0AC

//ckmu
#define SYSCLKEN		0x000FF200
#define SYSCLKCLR		0x000FF204
#define SYSCLKCFG		0x000FF208
#define SYSCLKFWCCFG		0x000FF20C

//rstmu
#define SYSINFST		0x000FF180
#define SYSRSTFLAG		0x000FF184
#define SYSRSTCFG		0x000FF188
#define SYSRSTCON		0x000FF18C
#define SYSSCICS		0x000FF190
#define SYSGRSTCON		0x000FF194

// powmu

#define SYSPCON		0x000FF284
#define SYSPCWKEN		0x000FF288
#define SYSPCGPSEL		0x000FF290

// sysmu
#define SYSWKCLK		0x000FF400
#define SYSCOMCON		0x000FF404
#define PULLDIS			0x000FF408
#define PULLMOD			0x000FF410
#define ADCTL			0x000FF41C
#define CPUSYSTICK		0x000FF438
#define UARTCNT			0x000FF43C
#define PACCON			0x000FF440
#define ANATEST    		0x000FF44C

#define KEYGENCFG		0x000FF444
#define CHIPID			0x000FF448
#define PRAMPRO    		0x000FF474

#define SYSREGRPT		0x000FF3FC

//WDT
#define WDTLOAD			0x000F0000
#define WDTVAL			0x000F0004
#define WDTCON			0x000F0008
#define WDTIS			0x000F000C 

// timer
#define TMR0LOAD           	0x000F0800
#define TMR0VAL            	0x000F0804
#define TMR0CON            	0x000F0808
#define TMR0IS             	0x000F080C
#define TMR1LOAD           	0x000F0820
#define TMR1VAL            	0x000F0824
#define TMR1CON            	0x000F0828
#define TMR1IS             	0x000F082C

// SCIS
#define SCIBUF 			0x000F1000
#define SCICON 			0x000F1004
#define SCISR 			0x000F1008
#define SCICNT 			0x000F100C
#define SCITXFCR		0x000F1010
#define SCIRXFCR		0x000F1014

//CRC
#define	CRCCSR			0x000F2000
#define	CRCDATA			0x000F2004
#define	CRCIV			0x000F2008

//RNG
#define RNGCTR            	0x000F2800
#define RNGSTR            	0x000F2804
#define RNGOUT          	0x000F2808
#define RNGIN             	0x000F280c
#define RNGMODE           	0x000F2810
#define TRNGTSTEN         	0x000F2814
#define TRNGTSTCTR       	0x000F2818
#define TRNGD             	0x000F2820

// GPIO
#define GPIODATA		0x000F3000
#define	GPIODIR			0x000F3004
#define	GPIOIS			0x000F3008
#define GPIOIBE			0x000F300C
#define	GPIOIEV 		0x000F3010
#define	GPIOIE			0x000F3014
#define GPIORIS			0x000F3018
#define	GPIOMIS			0x000F301C
#define	GPIOIC			0x000F3020

// I2C
#define I2CDRR          	0x000F5000
#define I2CCTR          	0x000F5004
#define I2CSR           	0x000F5008
#define I2CADDR         	0x000F500C
#define I2CDTR          	0x000F5010
#define I2CTO           	0x000F5014
#define I2CPRER         	0x000F5018
#define ADDRVALID         0x000F5028

// UART
#define	UARTCON				0x000F5800
#define UART_BAUD_FREQ  	0x000F5804
#define UART_BAUD_LIMIT 	0x000F5808
#define UART_RX_DATA    	0x000F580C
#define UART_TX_DATA   	 	0x000F5810

// SPI
#define SPICON         		0x000F6000
#define SPIDLEN        		0x000F6004
#define SPIST         		0x000F6008
#define SPIDIV        		0x000F600c
#define SPIIE         		0x000F6010
#define SPIIS         		0x000F6014
#define SPISTR        		0x000F6018
#define SPIDATA        		0x000F6040

//ahb
// ALG
#define	ALGCON			0x000FA800
#define	ALGKEY			0x000FA804
#define	ALGDATA			0x000FA80C
#define	ALGSEL			0x000FA808

// PKU
#define PKCRAM2     		0x000F8800
#define PKCRAM1     		0x000F9000
#define PKCCON      		0x000F8c00
#define PKCSEGN     		0x000F8c04
#define PKCND1      		0x000F8c08
#define PKCND0      		0x000F8c0c


// NVIC
#define NVIC_ISER		0xE000E100	 // Interrupt Set-Enable Register
#define NVIC_ICER		0xE000E180	 // Interrupt Clear Enable Registe
#define NVIC_ISPR		0xE000E200	 // Interrupt Set-Pending Register
#define NVIC_ICPR		0xE000E280	 // Interrupt Clear-Pending Register
#define NVIC_IPR0		0xE000E400	 // Interrupt Priority Registers
#define NVIC_IPR1		0xE000E404
#define NVIC_IPR2		0xE000E408
#define NVIC_IPR3		0xE000E40c
#define NVIC_IPR4		0xE000E410
#define NVIC_IPR5		0xE000E414
#define NVIC_IPR6		0xE000E418
#define NVIC_IPR7		0xE000E41c

#define   inp_w(addr)      		*(volatile UINT32*)(addr)
#define   inp_h(addr)      		*(volatile UINT16*)(addr)
#define   inp_b(addr)			*(volatile UINT8*)(addr)

#define   outp_w(addr, dat)     *(volatile UINT32*)(addr)=dat;
#define   outp_h(addr, dat)     *(volatile UINT16*)(addr)=dat;
#define   outp_b(addr, dat)		*(volatile UINT8*)(addr)=dat;

typedef unsigned char  	BOOLEAN;
typedef unsigned char  	UINT8;
typedef signed   char   SINT8;
typedef unsigned short 	UINT16;
typedef signed   short 	SINT16;
typedef unsigned long  	UINT32;
typedef signed long    	SINT32;
typedef unsigned char  	BYTE;
