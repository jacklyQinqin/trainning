/************************************************************/
/*				 		*/
/*				All Right Reserved							*/
/*�ļ����ƣ�is32u64a_gpio.h								*/
/*��    �ߣ�												*/
/*��ǰ�汾��V1.0.0											*/
/*��    �ڣ�2018-10-17										*/
/*����������	   											*/
/*		                                                    */
/*�޸����ݣ���������										*/
/************************************************************/

#ifndef _IS32U64A_GPIO_H__
#define _IS32U64A_GPIO_H__
#include "is32u64a_typesmacro.h"
#ifndef GPIO

#define GPIO1		1
#define GPIO2       2
#define GPIO3		3
#define GPIO4		4
#define GPIO5       5
#define GPIO6		6


#endif

#ifndef GPIO_GLOBAL
#define GPIO_EXT extern
#else
#define GPIO_EXT
#endif

GPIO_EXT void GpioInit(void);
GPIO_EXT void SetGpioXOut(UINT32 GPIOX);
GPIO_EXT void SetGpioXIn(UINT32 GPIOX);
GPIO_EXT void SetGpioXHigh(UINT32 GPIOX);
GPIO_EXT void SetGpioXLow(UINT32 GPIOX);

#endif
