
/*I2CCTR���ƼĴ�������*/
typedef enum {
	I2CENABLE,
	I2CDISABLE
}I2C_newState;

/*--------------------------Function -Decl---------------------*/
void SetRegVal(unsigned int registername,unsigned int paraaddress,unsigned int bit_count,unsigned int reg_bit_data);
void I2C_SlaveSend(void);
void I2C_SlaveSendTest(void);
void I2C_WaitingForStart(void);
void I2C_WaitingForAddrMatch(void);
void I2C_TimeOutEnable(I2C_newState newstate);
void I2C_InterruptEnable(I2C_newState newstate);
void I2C_SetACKFlag(I2C_newState newstate);
void I2C_ClearITFlag(void);
void I2C_ClearTransmitDoneFlag(void);
unsigned char I2C_CheckStop(void);
unsigned char I2C_ReadModeMasterReturnIsACK(void);
void I2C_SetSlaveMode(unsigned char addr);
unsigned char I2C_Direction(void);
unsigned char I2C_CheckDirection(void);
unsigned char I2C_SlaveSendBuff(unsigned char  * buff);
unsigned int I2C_ReceiveData(unsigned char  * revbuff);
unsigned char APDU(unsigned char * buff,unsigned char * sendbuff);

void SetSysClk32M(void);
void SetSysClk16M(void);
void SetSysClk8M(void);
void SetSysClk4M(void);
void SetSysClk2M(void);
