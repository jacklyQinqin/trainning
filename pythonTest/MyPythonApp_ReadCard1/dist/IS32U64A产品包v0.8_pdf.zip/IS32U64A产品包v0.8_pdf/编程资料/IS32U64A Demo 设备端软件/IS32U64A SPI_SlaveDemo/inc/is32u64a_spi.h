#include "is32u64a.h"
#include "is32u64a_typesmacro.h"

void SPI_SlaveModeInit(void);
void SPI_ReceiveOneByte(unsigned char * pRx,unsigned short len);
void SPI_TransmitOneByte(unsigned char * pTx,unsigned short len);